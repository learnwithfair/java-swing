package studentregistration;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class StudentRegistration extends JFrame implements ActionListener {

    protected Container c;
    protected JLabel lb, fnlb, lnlb, phnlb, gpalb, idlb;
    protected Font f = new Font("Times New Roman", Font.BOLD, 24);
    protected Font f1 = new Font("Times New Roman", Font.BOLD, 34);
    protected Font f2 = new Font("Times New Roman", Font.BOLD, 18);
    protected JTable tbl;
    protected JTextField fntf, lntf, phntf, gpatf, idtf;
    protected JButton addbtn, updbtn, dltbtn, clbtn, dltabtn;
    protected Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
    protected DefaultTableModel model;
    protected String[] cols = {"ID", "First Name", "Last Name", "Phone No", "GPA"};
    protected String[] row = new String[5];

    StudentRegistration() {
        this.setBounds(20, 29, 620, 700);
        this.setLocationRelativeTo(null);
        this.setTitle("Registration Form");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        lb = new JLabel();
        lb.setText("*Student Registration*");
        lb.setBounds(150, 10, 340, 70);
        lb.setForeground(Color.RED);
        lb.setFont(f1);
        c.add(lb);
        idlb = new JLabel();
        idlb.setText("Student ID :");
        idlb.setBounds(20, 80, 130, 60);
        idlb.setForeground(Color.BLUE);
        idlb.setFont(f);
        c.add(idlb);
        idtf = new JTextField();
        idtf.setBounds(170, 87, 240, 50);
        idtf.setToolTipText("Enter Student ID");
        idtf.setHorizontalAlignment(JTextField.CENTER);
        idtf.setFont(f);
        c.add(idtf);
        addbtn = new JButton("Add");
        addbtn.setBounds(420, 87, 140, 50);
        addbtn.setFont(f);
        addbtn.setCursor(cursor);
        c.add(addbtn);
        fnlb = new JLabel();
        fnlb.setText("Fast Name :");
        fnlb.setBounds(20, 140, 130, 60);
        fnlb.setForeground(Color.BLUE);
        fnlb.setFont(f);
        c.add(fnlb);
        fntf = new JTextField();
        fntf.setBounds(170, 147, 240, 50);
        fntf.setToolTipText("Enter Fast Name");
        fntf.setHorizontalAlignment(JTextField.CENTER);
        fntf.setFont(f);
        c.add(fntf);
        updbtn = new JButton("Update");
        updbtn.setBounds(420, 147, 140, 50);
        updbtn.setFont(f);
        updbtn.setCursor(cursor);
        c.add(updbtn);
        lnlb = new JLabel();
        lnlb.setText("Last Name :");
        lnlb.setBounds(20, 200, 130, 60);
        lnlb.setForeground(Color.BLUE);
        lnlb.setFont(f);
        c.add(lnlb);
        lntf = new JTextField();
        lntf.setBounds(170, 207, 240, 50);
        lntf.setToolTipText("Enter Last Name");
        lntf.setHorizontalAlignment(JTextField.CENTER);
        lntf.setFont(f);
        c.add(lntf);
        clbtn = new JButton("Clear");
        clbtn.setBounds(420, 207, 140, 50);
        clbtn.setFont(f);
        clbtn.setCursor(cursor);
        c.add(clbtn);
        phnlb = new JLabel();
        phnlb.setText("Phone No :");
        phnlb.setBounds(20, 260, 130, 60);
        phnlb.setForeground(Color.BLUE);
        phnlb.setFont(f);
        c.add(phnlb);
        phntf = new JTextField();
        phntf.setBounds(170, 267, 240, 50);
        phntf.setToolTipText("Enter Phone No");
        phntf.setHorizontalAlignment(JTextField.CENTER);
        phntf.setFont(f);
        c.add(phntf);
        dltbtn = new JButton("Delete");
        dltbtn.setBounds(420, 267, 140, 50);
        dltbtn.setFont(f);
        dltbtn.setCursor(cursor);
        c.add(dltbtn);
        gpalb = new JLabel();
        gpalb.setText("GPA :");
        gpalb.setBounds(20, 320, 130, 60);
        gpalb.setForeground(Color.BLUE);
        gpalb.setFont(f);
        c.add(gpalb);
        gpatf = new JTextField();
        gpatf.setBounds(170, 327, 240, 50);
        gpatf.setToolTipText("Enter GPA");
        gpatf.setHorizontalAlignment(JTextField.CENTER);
        gpatf.setFont(f);
        c.add(gpatf);
        dltabtn = new JButton("Delete All");
        dltabtn.setBounds(420, 327, 140, 50);
        dltabtn.setFont(f);
        dltabtn.setCursor(cursor);
        c.add(dltabtn);
        model = new DefaultTableModel();
        model.setColumnIdentifiers(cols);
        tbl = new JTable(model);
        //tbl.setModel(model);
        tbl.setBackground(Color.WHITE);
        tbl.setSelectionBackground(Color.GREEN);
        tbl.setFont(f2);
        tbl.setRowHeight(40);
        JScrollPane scroll = new JScrollPane(tbl);
        scroll.setBounds(5, 385, 556, 250);
        c.add(scroll);
        addbtn.addActionListener(this);
        clbtn.addActionListener(this);
        dltbtn.addActionListener(this);
        updbtn.addActionListener(this);
        dltabtn.addActionListener(this);
        tbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int numOfRow = tbl.getSelectedRow();
                //tbl.addRowSelectionInterval(1, 3);
                String id = model.getValueAt(numOfRow, 0).toString();
                String f_name = model.getValueAt(numOfRow, 1).toString();
                String l_name = model.getValueAt(numOfRow, 2).toString();
                String phn = model.getValueAt(numOfRow, 3).toString();
                String gpa = model.getValueAt(numOfRow, 4).toString();
                idtf.setText(id);
                fntf.setText(f_name);
                lntf.setText(l_name);
                phntf.setText(phn);
                gpatf.setText(gpa);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addbtn) {
            row[0] = idtf.getText();
            row[1] = fntf.getText();
            row[2] = lntf.getText();
            row[3] = phntf.getText();
            row[4] = gpatf.getText();
            model.addRow(row);
        } else if (e.getSource() == clbtn) {
            idtf.setText("");
            fntf.setText("");
            lntf.setText("");
            phntf.setText("");
            gpatf.setText("");
        } else if (e.getSource() == dltbtn) {
            int numOfRow = tbl.getSelectedRow();
            if (numOfRow >= 0) {
                //model.removeRow(numOfRow);
                int r[] = tbl.getSelectedRows();
                Arrays.sort(r);
                int n = r.length;
                for (int i = n - 1; i >= 0; i--) {
                    model.removeRow(r[i]);
                }
            } else {
                JOptionPane.showMessageDialog(gpatf, "You have't Selected Row.Please try again");
            }
        } else if (e.getSource() == updbtn) {
            int numOfRow = tbl.getSelectedRow();
            if (numOfRow >= 0) {
                String id = idtf.getText();
                String f_name = fntf.getText();
                String l_name = lntf.getText();
                String phn = phntf.getText();
                String gpa = gpatf.getText();
                model.setValueAt(id, numOfRow, 0);
                model.setValueAt(f_name, numOfRow, 1);
                model.setValueAt(l_name, numOfRow, 2);
                model.setValueAt(phn, numOfRow, 3);
                model.setValueAt(gpa, numOfRow, 4);
            } else {
                JOptionPane.showMessageDialog(gpatf, "Please Select Row than try again.");
            }
        } else if (e.getSource() == dltabtn) {
            int numOfRows = tbl.getRowCount();
            if (numOfRows > 0) {
                for (int i = numOfRows - 1; i >= 0; i--) {
                    model.removeRow(i);
                }
            } else {
                JOptionPane.showMessageDialog(gpatf, "Table is Empty please try again.");
            }
        }
    }

    public static void main(String[] args) {
        StudentRegistration frm = new StudentRegistration();
        frm.setVisible(true);
    }
}

package studentregistrationform2;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Arrays;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

public class StudentRegistrationDemo extends JFrame implements ActionListener {

    protected Container c;

    protected JLabel namelb2, idlb2, fathernamelb2, mothernamelb2, birthlb2, meritiallb2, backgroundlb, signaturelb2, heddinglb,
            presentlb2, permanentlb2, contactlb2, emaillb2, religionlb2, genderlb2, bloadlb2, nationalitilb2, heightlb2, weightlb12, heddinglb2;
    protected JPanel pnl, firstpnl, secondpnl, thirdpnl, tablepnl, signatturepnl, pnldemo, pnl1, pnl2;
    static String id, name, fathername, mothername, birth, meritial,
            present, permanent, contact, email, religion, gender, bload, nationality, height, weight;
    protected Font f1 = new Font("Times New Roman", Font.BOLD, 70);
    protected CardLayout clayout = new CardLayout();
    protected Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
    protected int count = 0, r = 0, t = -1;
    protected Font f2 = new Font("Times New Roman", Font.BOLD, 24);
    protected Font f3 = new Font("Times New Roman", Font.BOLD, 20);
    public JTextField idtf, nametf, fathernametf, mothernametf, birthtf, meritialtf,
            presenttf, permanenttf, contacttf, emailtf, religiontf, gendertf, heightf;
    protected JLabel namelb, idlb, fathernamelb, mothernamelb, birthlb, meritiallb,
            presentlb, permanentlb, contactlb, emaillb, religionlb, genderlb, bloadlb, nationalitilb, heightlb, weightlb1, weightlb2;
    protected JComboBox cbox, bloadcbox, nationaliticbox;
    protected JScrollPane scroll;
    protected JRadioButton malebtn, femalebtn, otherbtn;
    protected ButtonGroup grp;
    protected JSpinner weightsp;
    protected JButton nextbtn, previousbtn, savebtn, cancelbtn;
    //panel2

    protected int numberOfRow = -1, rowcount = 0;
    protected JTable tbl;
    protected JButton deletebtn, deleteallbtn, updatebtn, addbtn, showbtn, clearbtn, signaturebtn;
    protected JTextField institudetf, gpatf;
    protected DefaultTableModel model2;
    protected JComboBox examinationcbox, boardcbox, yearcbox;
    protected JLabel educationlb, examinationlb, institudelb, yearlb, gpalb, boardlb, signaturelb;
    protected static String education, examination, institude, year, gpa, board, signaturetext;
    protected Font f4 = new Font("Times New Roman", Font.BOLD, 18);
    protected Font f5 = new Font("Times New Roman", Font.BOLD + Font.ITALIC, 24);
    protected String[] cols = {"Name of Institution", "Examination", "Board", "Passing Year", "GPA / CGP"};
    protected String[] row = new String[5];
    protected String[] strname = new String[5];

    StudentRegistrationDemo() {
        this.setBounds(0, 0, 1350, 700);
        this.setTitle("Student Registration Form");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.LIGHT_GRAY);

        heddinglb = new JLabel();
        heddinglb.setText("\"Student's Registration Form\"");
        heddinglb.setFont(f1);
        heddinglb.setBounds(210, 0, 940, 75);
        heddinglb.setForeground(Color.BLUE);
        c.add(heddinglb);

        pnldemo = new JPanel();

        pnldemo.setBackground(Color.LIGHT_GRAY);
        pnldemo.setLayout(clayout);
        pnldemo.setBounds(20, 80, 1320, 590);

        pnl1 = new JPanel();

        pnl1.setBackground(Color.LIGHT_GRAY);
        pnl1.setLayout(null);
        pnl1.setBounds(20, 40, 1320, 650);
        idlb = new JLabel("Enter Student ID        : ");
        idlb.setBounds(0, 40, 250, 60);
        idlb.setFont(f2);
        pnl1.add(idlb);
        idtf = new JTextField();
        idtf.setBounds(250, 40, 350, 60);
        idtf.setBackground(Color.LIGHT_GRAY);
        idtf.setToolTipText("Student ID Hint's : 190609");
        idtf.setSelectionColor(Color.RED);
        idtf.setHorizontalAlignment(JTextField.CENTER);
        idtf.setFont(f2);
        pnl1.add(idtf);

        namelb = new JLabel("Enter Student Name   : ");
        namelb.setBounds(700, 40, 250, 60);
        namelb.setFont(f2);
        pnl1.add(namelb);
        nametf = new JTextField();
        nametf.setBounds(963, 40, 350, 60);
        nametf.setBackground(Color.LIGHT_GRAY);
        nametf.setToolTipText("Student Name Hint's : Md Rahatul Islam");
        nametf.setSelectionColor(Color.RED);
        nametf.setHorizontalAlignment(JTextField.CENTER);
        nametf.setFont(f2);
        pnl1.add(nametf);

        fathernamelb = new JLabel("Enter Father's Name : ");
        fathernamelb.setBounds(0, 110, 250, 60);
        fathernamelb.setFont(f2);
        pnl1.add(fathernamelb);
        fathernametf = new JTextField();
        fathernametf.setBounds(250, 110, 350, 60);
        fathernametf.setBackground(Color.LIGHT_GRAY);
        fathernametf.setToolTipText("Faher's Name Hint's : Mohammad Ali");
        fathernametf.setSelectionColor(Color.RED);
        fathernametf.setHorizontalAlignment(JTextField.CENTER);
        fathernametf.setFont(f2);
        pnl1.add(fathernametf);

        mothernamelb = new JLabel("Enter Mother's Name : ");
        mothernamelb.setBounds(700, 110, 250, 60);
        mothernamelb.setFont(f2);
        pnl1.add(mothernamelb);
        mothernametf = new JTextField();
        mothernametf.setBounds(963, 110, 350, 60);
        mothernametf.setBackground(Color.LIGHT_GRAY);
        mothernametf.setToolTipText("Moher's Name Hint's : Most. Sultana Raziya");
        mothernametf.setSelectionColor(Color.RED);
        mothernametf.setHorizontalAlignment(JTextField.CENTER);
        mothernametf.setFont(f2);
        pnl1.add(mothernametf);

        birthlb = new JLabel("Enter Date of Birth    : ");
        birthlb.setBounds(0, 180, 250, 60);
        birthlb.setFont(f2);
        pnl1.add(birthlb);
        birthtf = new JTextField();
        birthtf.setBounds(250, 180, 350, 60);
        birthtf.setBackground(Color.LIGHT_GRAY);
        birthtf.setToolTipText("Date of Birth Hint's : 03-03-1999");
        birthtf.setSelectionColor(Color.RED);
        birthtf.setHorizontalAlignment(JTextField.CENTER);
        birthtf.setFont(f2);
        pnl1.add(birthtf);

        meritiallb = new JLabel("Select Marital Status  : ");
        meritiallb.setBounds(700, 180, 250, 60);
        meritiallb.setFont(f2);
        pnl1.add(meritiallb);
        cbox = new JComboBox();
        cbox.setBounds(963, 180, 350, 60);
        cbox.setBackground(Color.LIGHT_GRAY);
        cbox.addItem("                     Married");
        cbox.addItem("                     Unmarried");
        cbox.setSelectedIndex(0);
        cbox.setToolTipText("Marital Status Hint's : Married / Unmarried");
        cbox.setEditable(false);
        cbox.setFont(f2);
        pnl1.add(cbox);

        genderlb = new JLabel("Select any Gender      : ");
        genderlb.setBounds(0, 250, 250, 60);

        genderlb.setFont(f2);
        pnl1.add(genderlb);
        malebtn = new JRadioButton("Male");
        malebtn.setBackground(Color.LIGHT_GRAY);
        malebtn.setFont(f2);
        malebtn.setBounds(250, 250, 90, 60);
        pnl1.add(malebtn);
        femalebtn = new JRadioButton("Female");
        femalebtn.setBackground(Color.LIGHT_GRAY);
        femalebtn.setFont(f2);
        femalebtn.setBounds(370, 250, 120, 60);
        pnl1.add(femalebtn);
        otherbtn = new JRadioButton("Other", true);
        otherbtn.setBounds(520, 250, 90, 60);
        otherbtn.setBackground(Color.LIGHT_GRAY);
        otherbtn.setFont(f2);
        pnl1.add(otherbtn);
        grp = new ButtonGroup();
        grp.add(malebtn);
        grp.add(femalebtn);
        grp.add(otherbtn);

        religionlb = new JLabel("Enter Student Religion       :");
        religionlb.setBounds(700, 250, 250, 60);
        religionlb.setFont(f3);
        pnl1.add(religionlb);
        religiontf = new JTextField();
        religiontf.setBounds(963, 250, 350, 60);
        religiontf.setBackground(Color.LIGHT_GRAY);
        religiontf.setHorizontalAlignment(JTextField.CENTER);
        religiontf.setToolTipText("Religion Hint's : Islam,Hindu");
        religiontf.setFont(f2);
        pnl1.add(religiontf);

        contactlb = new JLabel("Student Mobile Number     : ");
        contactlb.setBounds(0, 320, 250, 60);
        contactlb.setFont(f3);
        pnl1.add(contactlb);
        contacttf = new JTextField("            +088");
        contacttf.setBounds(250, 320, 350, 60);
        contacttf.setBackground(Color.LIGHT_GRAY);
        contacttf.setToolTipText("Mobile Number Hint's : 01790224950");
        contacttf.setSelectionColor(Color.RED);
        contacttf.setFont(f3);
        pnl1.add(contacttf);
        contacttf.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent ke) {
            }

            @Override
            public void keyPressed(KeyEvent ke) {
                if (ke.getKeyCode() >= 48 && ke.getKeyCode() <= 57) {
                    count++;
                    r = 0;
                } else if (ke.getKeyCode() == 8 || ke.getKeyCode() == 127) {

                    if (count > 0) {
                        count--;

                    }
                    r = 0;
                } else {
                    r++;
                    JOptionPane.showMessageDialog(contacttf, "This Phone Number is Invalid Please Try Again.");
                    StringBuilder str = new StringBuilder();
                    str.append(contacttf.getText());
                    char ca = ke.getKeyChar();
                    String s = String.valueOf(ca);
                    int f = str.lastIndexOf(s);
                    String value = str.deleteCharAt(f).toString();
                    contacttf.setText(value);
                }
                if (r == 0 && count > 11) {
                    r = 0;
                    count--;
                    JOptionPane.showMessageDialog(contacttf, "This Phone Number Length is Invalid Please Try Again.");
                    StringBuilder str2 = new StringBuilder();
                    str2.append(contacttf.getText());
                    char ca2 = ke.getKeyChar();
                    String s2 = String.valueOf(ca2);
                    int f2 = str2.lastIndexOf(s2);
                    String value2 = str2.deleteCharAt(f2).toString();
                    contacttf.setText(value2);

                }

            }

            @Override
            public void keyReleased(KeyEvent ke) {
                String str = contacttf.getText();
                String str2 = "            +088" + ke.getKeyChar();
                if (str.isEmpty()) {
                    count = 0;
                    r = 0;
                    contacttf.setText("            +088");
                }
                if (str2.equals(str)) {
                    count = 1;
                    r = 0;
                    contacttf.setText(str2);
                }
            }

        });
        contacttf.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe) {
            }

            @Override
            public void focusLost(FocusEvent fe) {
                if (r == 0) {

                    if (count > 0 && count < 11) {
                        JOptionPane.showMessageDialog(contacttf, "This Phone Number Length is Invalid Please Try Again.");
                    }
                }

            }

        });

        emaillb = new JLabel("Enter Student Email ID      : ");
        emaillb.setBounds(700, 320, 250, 60);
        emaillb.setFont(f3);
        pnl1.add(emaillb);
        emailtf = new JTextField();
        emailtf.setBounds(963, 320, 350, 60);
        emailtf.setBackground(Color.LIGHT_GRAY);
        emailtf.setHorizontalAlignment(JTextField.CENTER);
        emailtf.setToolTipText("Email ID Hint's : rahatul.ice.09.pust@gmail.com");
        emailtf.setFont(f3);
        pnl1.add(emailtf);

        presentlb = new JLabel("Enter Present Address       : ");
        presentlb.setBounds(0, 390, 250, 60);
        presentlb.setFont(f3);
        pnl1.add(presentlb);
        presenttf = new JTextField();
        presenttf.setBounds(250, 390, 350, 60);
        presenttf.setBackground(Color.LIGHT_GRAY);
        presenttf.setToolTipText("Present Address Hint's : Loskarpur,Pabna,Rajshahi");
        presenttf.setSelectionColor(Color.RED);
        presenttf.setHorizontalAlignment(JTextField.CENTER);
        presenttf.setFont(f3);
        pnl1.add(presenttf);

        permanentlb = new JLabel("Enter Permanent Address  : ");
        permanentlb.setBounds(700, 390, 250, 60);
        permanentlb.setFont(f3);
        pnl1.add(permanentlb);
        permanenttf = new JTextField();
        permanenttf.setBounds(963, 390, 350, 60);
        permanenttf.setBackground(Color.LIGHT_GRAY);
        permanenttf.setHorizontalAlignment(JTextField.CENTER);
        permanenttf.setToolTipText(" Permanent Address Hint's : Hatibandha, Lalmonirhat,Rangpur");
        permanenttf.setFont(f3);
        pnl1.add(permanenttf);

        heightlb = new JLabel("Enter Student Height : ");
        heightlb.setBounds(0, 460, 250, 60);
        heightlb.setFont(f2);
        pnl1.add(heightlb);
        heightf = new JTextField();
        heightf.setBounds(250, 460, 350, 60);
        heightf.setBackground(Color.LIGHT_GRAY);
        heightf.setToolTipText("Student Height Hint's : 5.9''");
        heightf.setSelectionColor(Color.RED);
        heightf.setHorizontalAlignment(JTextField.CENTER);
        heightf.setFont(f2);
        pnl1.add(heightf);

        weightlb1 = new JLabel("Select Student Weight : ");
        weightlb1.setBounds(700, 460, 250, 60);
        weightlb1.setFont(f2);
        pnl1.add(weightlb1);
        SpinnerNumberModel model = new SpinnerNumberModel(40, 20, 90, 1);
        weightsp = new JSpinner(model);
        weightsp.setFont(f1);
        weightsp.setBackground(Color.LIGHT_GRAY);
        weightsp.setBounds(963, 460, 200, 60);
        pnl1.add(weightsp);
        weightlb2 = new JLabel("Kg");
        weightlb2.setBounds(1190, 460, 150, 75);
        weightlb2.setFont(f1);
        pnl1.add(weightlb2);

        bloadlb = new JLabel("Selecte your Bload Group :");
        bloadlb.setBounds(0, 530, 250, 50);
        bloadlb.setFont(f3);
        pnl1.add(bloadlb);
        String[] str = {"                    A+", "                    A-", "                    B+",
            "                    B-", "                    AB+", "                    AB-", "                    O+", "                    O-"};
        bloadcbox = new JComboBox(str);
        bloadcbox.setBounds(250, 530, 350, 50);
        bloadcbox.setSelectedIndex(4);
        bloadcbox.setBackground(Color.LIGHT_GRAY);
        bloadcbox.setFont(f2);
        pnl1.add(bloadcbox);

        nationalitilb = new JLabel("Enter Student Nationality   :");
        nationalitilb.setBounds(700, 530, 250, 50);
        nationalitilb.setFont(f3);
        pnl1.add(nationalitilb);
        String[] countryname = {"    America", "    Argentina", "    Bhutan", "    Bangladesh",
            "    Brazil", "    Canada", "    England", "    Japan", "    India", "    Pakistan", "    Rasia", "    London"};
        nationaliticbox = new JComboBox(countryname);
        nationaliticbox.setBounds(963, 530, 200, 50);
        nationaliticbox.setBackground(Color.LIGHT_GRAY);
        nationaliticbox.setSelectedIndex(3);
        nationaliticbox.setFont(f2);
        pnl1.add(nationaliticbox);

        previousbtn = new JButton("Previous");
        previousbtn.setBounds(0, 670, 140, 40);
        previousbtn.setFont(f2);
        previousbtn.setBackground(Color.LIGHT_GRAY);
        previousbtn.setCursor(cursor);
        previousbtn.setForeground(Color.RED);
        c.add(previousbtn);

        nextbtn = new JButton("Next");
        nextbtn.setBounds(1250, 670, 90, 40);
        nextbtn.setFont(f2);
        nextbtn.setForeground(Color.RED);
        nextbtn.setCursor(cursor);
        nextbtn.setBackground(Color.LIGHT_GRAY);
        c.add(nextbtn);

        pnldemo.add(pnl1);
        //Panel2

        pnl2 = new JPanel();
        pnl2.setLayout(null);
        pnl2.setBackground(Color.LIGHT_GRAY);

        examinationlb = new JLabel("Select Examination     : ");
        examinationlb.setBounds(0, 20, 250, 50);
        examinationlb.setFont(f2);
        pnl2.add(examinationlb);
        String[] examinationname = {"                P.S.C", "                J.S.C", "                S.S.C",
            "                H.S.C", "                B.Sc", "                B.A", "                B.B.A", "                M.A", "                M.S.C", "                Other"};
        examinationcbox = new JComboBox(examinationname);
        examinationcbox.setBounds(260, 20, 350, 50);
        examinationcbox.setSelectedIndex(4);
        examinationcbox.setBackground(Color.LIGHT_GRAY);
        examinationcbox.setFont(f2);
        pnl2.add(examinationcbox);

        boardlb = new JLabel("Select Exam Borad     : ");
        boardlb.setBounds(700, 20, 250, 50);
        boardlb.setFont(f2);
        pnl2.add(boardlb);
        String[] boardname = {"             Borishal", "             Chittagone", "              Comilla", "               Dhaka",
            "             Dinajpur", "                Jasor", "             Madrasah", "             Rajshahi", "               Seylet", "                Other"};
        boardcbox = new JComboBox(boardname);
        boardcbox.setBounds(960, 20, 350, 50);
        boardcbox.setSelectedIndex(6);
        boardcbox.setBackground(Color.LIGHT_GRAY);
        boardcbox.setFont(f2);
        pnl2.add(boardcbox);

        institudelb = new JLabel("Enter Name of Institution     : ");
        institudelb.setBounds(130, 90, 350, 50);
        institudelb.setFont(f2);
        pnl2.add(institudelb);

        institudetf = new JTextField("    ");
        institudetf.setBounds(490, 90, 670, 50);
        institudetf.setBackground(Color.LIGHT_GRAY);
        institudetf.setToolTipText("Institude Name Hint's : Pabna University of Science and Tecnology''");
        institudetf.setSelectionColor(Color.RED);
        institudetf.setHorizontalAlignment(JTextField.CENTER);
        institudetf.setFont(f2);
        pnl2.add(institudetf);

        yearlb = new JLabel("Select Passing Year    : ");
        yearlb.setBounds(0, 160, 250, 50);
        yearlb.setFont(f2);
        pnl2.add(yearlb);
        String[] yearname = {"                2030", "                2029", "                2028", "                2027",
            "                2026", "                2025", "                2024", "                2023", "                2022",
            "                2021", "                2020", "                2019", "                2018", "                2017",
            "                2016", "                2015", "                2014", "                2013", "                2012",
            "                2011", "                2010", "                2009", "                2008", "                2007", "                2006",
            "                2005", "                2004", "                2003", "                2002", "                2001", "                2000",
            "                1999", "                1998", "                1997", "                1996", "                1995", "                1994",
            "                1993", "                1992", "                1991", "                1990"};
        yearcbox = new JComboBox(yearname);
        yearcbox.setBounds(260, 160, 350, 50);
        yearcbox.setSelectedIndex(10);
        yearcbox.setBackground(Color.LIGHT_GRAY);
        yearcbox.setFont(f2);
        pnl2.add(yearcbox);

        gpalb = new JLabel("Enter GPA / CGPA    : ");
        gpalb.setBounds(700, 160, 350, 50);
        gpalb.setFont(f2);
        pnl2.add(gpalb);

        gpatf = new JTextField("                 ");
        gpatf.setBounds(960, 160, 350, 50);
        gpatf.setBackground(Color.LIGHT_GRAY);
        gpatf.setToolTipText("GPA / CGPA Hint's : 5.00 / 3.88");
        gpatf.setSelectionColor(Color.RED);
        gpatf.setFont(f2);
        pnl2.add(gpatf);

        gpatf.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String gpatext = gpatf.getText();
                if (gpatext.isEmpty() || gpatext.equals("                 ")) {
                    gpatf.setText("                 ");
                }

            }

        });

        deleteallbtn = new JButton("Delete All");
        deleteallbtn.setBackground(Color.LIGHT_GRAY);
        deleteallbtn.setBounds(20, 230, 190, 50);
        deleteallbtn.setCursor(cursor);
        deleteallbtn.setFont(f2);
        deleteallbtn.setForeground(Color.RED);
        pnl2.add(deleteallbtn);

        deletebtn = new JButton("Delete");
        deletebtn.setBackground(Color.LIGHT_GRAY);
        deletebtn.setBounds(290, 230, 190, 50);
        deletebtn.setCursor(cursor);
        deletebtn.setFont(f2);
        deletebtn.setForeground(Color.RED);
        pnl2.add(deletebtn);
        clearbtn = new JButton("Clear");
        clearbtn.setBackground(Color.LIGHT_GRAY);
        clearbtn.setBounds(560, 230, 190, 50);
        clearbtn.setCursor(cursor);
        clearbtn.setFont(f2);
        clearbtn.setForeground(Color.RED);
        pnl2.add(clearbtn);
        updatebtn = new JButton("Update");
        updatebtn.setBackground(Color.LIGHT_GRAY);
        updatebtn.setBounds(830, 230, 190, 50);
        updatebtn.setCursor(cursor);
        updatebtn.setFont(f2);
        updatebtn.setForeground(Color.RED);
        pnl2.add(updatebtn);

        addbtn = new JButton("Add");
        addbtn.setBackground(Color.LIGHT_GRAY);
        addbtn.setBounds(1100, 230, 190, 50);
        addbtn.setCursor(cursor);
        addbtn.setFont(f2);
        addbtn.setForeground(Color.RED);
        pnl2.add(addbtn);

        model2 = new DefaultTableModel();
        model2.setColumnIdentifiers(cols);
        tbl = new JTable(model2);
        tbl.setBackground(Color.LIGHT_GRAY);
        tbl.setFont(f4);
        tbl.setSelectionBackground(Color.GREEN);
        tbl.setRowHeight(40);

        tbl.sizeColumnsToFit(0);
        // tbl.setRowSelectionAllowed(true);
        //tbl.setColumnSelectionAllowed(false);
        tbl.setSelectionForeground(Color.RED);

        scroll = new JScrollPane(tbl);
        scroll.setBounds(0, 300, 1320, 183);
        scroll.setBackground(Color.LIGHT_GRAY);
        pnl2.add(scroll);

        tbl.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                numberOfRow = tbl.getSelectedRow();
                String institutiontext = model2.getValueAt(numberOfRow, 0).toString();
                String examinationtext = model2.getValueAt(numberOfRow, 1).toString();
                String boardtext = model2.getValueAt(numberOfRow, 2).toString();
                String passingyeartext = model2.getValueAt(numberOfRow, 3).toString();
                String gpatext = model2.getValueAt(numberOfRow, 4).toString();
                examinationcbox.setSelectedItem(examinationtext);
                boardcbox.setSelectedItem(boardtext);
                institudetf.setText(institutiontext);
                yearcbox.setSelectedItem(passingyeartext);
                gpatf.setText(gpatext);

            }
        });

        signaturebtn = new JButton("Set Signature");
        signaturebtn.setBounds(570, 550, 180, 40);
        signaturebtn.setFont(f2);
        signaturebtn.setBackground(Color.LIGHT_GRAY);
        signaturebtn.setCursor(cursor);
        pnl2.add(signaturebtn);

        signaturelb = new JLabel("_________________");
        signaturelb.setBounds(560, 505, 450, 50);
        signaturelb.setFont(f5);
        pnl2.add(signaturelb);

        showbtn = new JButton("Show");
        showbtn.setBounds(1135, 520, 180, 50);
        showbtn.setFont(f2);
        showbtn.setBackground(Color.LIGHT_GRAY);
        showbtn.setCursor(cursor);
        showbtn.setForeground(Color.BLUE);
        pnl2.add(showbtn);

        pnldemo.add(pnl2);
        //show class 

        c.add(pnldemo);

        addbtn.addActionListener(this);
        clearbtn.addActionListener(this);
        deletebtn.addActionListener(this);
        deleteallbtn.addActionListener(this);
        updatebtn.addActionListener(this);
        signaturebtn.addActionListener(this);
        showbtn.addActionListener(this);
        previousbtn.addActionListener(this);
        nextbtn.addActionListener(this);

    }

    //panel2ActionListener
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addbtn) {
            rowcount = model2.getRowCount();
            if (rowcount <= 3) {
                row[0] = institudetf.getText();
                row[1] = examinationcbox.getSelectedItem().toString();
                row[2] = boardcbox.getSelectedItem().toString();
                row[3] = yearcbox.getSelectedItem().toString();
                row[4] = gpatf.getText();
                model2.addRow(row);
            } else {
                JOptionPane.showMessageDialog(tbl, "Already you have inserted four item . Please at first delete item then Try Again.", "Warning Message", JOptionPane.WARNING_MESSAGE);

            }

        } else if (e.getSource() == clearbtn) {
            examinationcbox.setSelectedIndex(4);
            boardcbox.setSelectedIndex(6);
            institudetf.setText("    ");
            yearcbox.setSelectedIndex(10);
            gpatf.setText("                 ");
        } else if (e.getSource() == updatebtn) {
            int r1 = model2.getRowCount();
            if (r1 <= 0) {
                JOptionPane.showMessageDialog(tbl, "This Table is Empty. Please at first Insert Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
            } else if (numberOfRow == -1) {
                JOptionPane.showMessageDialog(tbl, "You have not Selected Row. Please at first Select Row then Try Again.", "Error Message", JOptionPane.ERROR_MESSAGE);
            } else {
                strname[0] = institudetf.getText();
                strname[1] = examinationcbox.getSelectedItem().toString();
                strname[2] = boardcbox.getSelectedItem().toString();
                strname[3] = yearcbox.getSelectedItem().toString();
                strname[4] = gpatf.getText();
                tbl.setValueAt(strname[0], numberOfRow, 0);
                tbl.setValueAt(strname[1], numberOfRow, 1);
                tbl.setValueAt(strname[2], numberOfRow, 2);
                tbl.setValueAt(strname[3], numberOfRow, 3);
                tbl.setValueAt(strname[4], numberOfRow, 4);
            }
        } else if (e.getSource() == deletebtn) {
            int r2 = 0;
            r2 = model2.getRowCount();
            if (r2 < 1) {
                JOptionPane.showMessageDialog(tbl, "This Table is Empty. Please at first Insert Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
            } else if (numberOfRow == -1) {
                int[] rowscount = tbl.getSelectedRows();
                Arrays.sort(rowscount);
                int n = rowscount.length;
                if (n == 0) {
                    JOptionPane.showMessageDialog(tbl, "You have not Selected Row. Please at first Select Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
                } else {
                    for (int i = n - 1; i >= 0; i--) {
                        model2.removeRow(rowscount[i]);
                    }
                    numberOfRow = -1;
                }

            } else {
                int[] rowscount2 = tbl.getSelectedRows();
                Arrays.sort(rowscount2);
                int n2 = rowscount2.length;
                for (int i = n2 - 1; i >= 0; i--) {
                    model2.removeRow(rowscount2[i]);
                }
                numberOfRow = -1;
            }
        } else if (e.getSource() == deleteallbtn) {
            int r2 = 0;
            r2 = model2.getRowCount();
            if (r2 < 1) {
                JOptionPane.showMessageDialog(tbl, "This Table is Empty. Please at first Insert Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
            } else {
                for (int i = r2 - 1; i >= 0; i--) {
                    model2.removeRow(i);

                }
            }
        } else if (e.getSource() == signaturebtn) {
            String signature = JOptionPane.showInputDialog(tbl, "Enter Your Signature", "Signature Input", JOptionPane.INFORMATION_MESSAGE);
            if (signature.isEmpty()) {
                JOptionPane.showMessageDialog(tbl, "You have no Signature Please Try Again.", "Error Message", JOptionPane.ERROR_MESSAGE);
            } else {
                signaturelb.setText(signature);
            }
        } else if (e.getSource() == showbtn) {
            pnldemo.setVisible(false);
            nextbtn.setVisible(false);
            previousbtn.setVisible(false);
            heddinglb.setVisible(false);
            name = nametf.getText().trim();
            id = idtf.getText().trim();
            fathername = fathernametf.getText().trim();
            mothername = mothernametf.getText().trim();
            birth = birthtf.getText().trim();
            meritial = cbox.getSelectedItem().toString().trim();
            present = presenttf.getText().trim();
            permanent = permanenttf.getText().trim();
            contact = contacttf.getText().trim();
            email = emailtf.getText().trim();
            religion = religiontf.getText().trim();

            if (malebtn.isSelected()) {
                gender = "Male";
            } else if (femalebtn.isSelected()) {
                gender = "Female";
            } else if (otherbtn.isSelected()) {
                gender = "Other";
            }
            bload = bloadcbox.getSelectedItem().toString().trim();
            nationality = nationaliticbox.getSelectedItem().toString().trim();
            height = heightf.getText().trim();
            weight = weightsp.getValue().toString().trim();
            signaturetext = signaturelb.getText().trim();
            heddinglb2 = new JLabel();

            heddinglb2.setText("\"Student Registration Form\"");
            heddinglb2.setFont(f1);
            heddinglb2.setBounds(210, 0, 940, 75);
            heddinglb2.setForeground(Color.BLACK);
            c.add(heddinglb2);
            GridLayout glayout = new GridLayout(1, 3);
            Font font = new Font("Times New Roman", Font.BOLD, 16);
            pnl = new JPanel();
            pnl.setBounds(20, 110, 1320, 200);
            pnl.setBackground(Color.LIGHT_GRAY);
            pnl.setLayout(glayout);

            //First panel
            firstpnl = new JPanel();
            firstpnl.setBackground(Color.LIGHT_GRAY);
            BoxLayout blayout2 = new BoxLayout(firstpnl, BoxLayout.Y_AXIS);
            firstpnl.setLayout(blayout2);

            idlb2 = new JLabel();
            idlb2.setText("Student ID              :   " + id);
            idlb2.setFont(font);
            firstpnl.add(idlb2);
            firstpnl.add(Box.createVerticalStrut(10));

            mothernamelb2 = new JLabel();
            mothernamelb2.setText("Mother's Name      :   " + mothername);
            mothernamelb2.setFont(font);
            firstpnl.add(mothernamelb2);
            firstpnl.add(Box.createVerticalStrut(10));

            presentlb2 = new JLabel();
            presentlb2.setText("Present Address     :   " + present);
            presentlb2.setFont(font);
            firstpnl.add(presentlb2);
            firstpnl.add(Box.createVerticalStrut(10));

            emaillb2 = new JLabel();
            emaillb2.setText("Student Email DI    :   " + email);
            emaillb2.setFont(font);
            firstpnl.add(emaillb2);
            firstpnl.add(Box.createVerticalStrut(10));

            bloadlb2 = new JLabel();
            bloadlb2.setText("Bload Group            :   " + bload);
            bloadlb2.setFont(font);
            firstpnl.add(bloadlb2);
            firstpnl.add(Box.createVerticalStrut(30));

            backgroundlb = new JLabel();
            backgroundlb.setText("Educational Background   :");
            backgroundlb.setFont(f5);
            firstpnl.add(backgroundlb);

            //Second panel
            secondpnl = new JPanel();
            secondpnl.setBackground(Color.LIGHT_GRAY);
            BoxLayout blayout3 = new BoxLayout(secondpnl, BoxLayout.Y_AXIS);
            secondpnl.setLayout(blayout3);

            namelb2 = new JLabel();
            namelb2.setText("Student Name            :   " + name);
            namelb2.setFont(font);
            secondpnl.add(namelb2);
            secondpnl.add(Box.createVerticalStrut(10));

            birthlb2 = new JLabel();
            birthlb2.setText("Student Birhday         :   " + birth);
            birthlb2.setFont(font);
            secondpnl.add(birthlb2);
            secondpnl.add(Box.createVerticalStrut(10));

            permanentlb2 = new JLabel();
            permanentlb2.setText("Permanent Address   :   " + permanent);
            permanentlb2.setFont(font);
            secondpnl.add(permanentlb2);
            secondpnl.add(Box.createVerticalStrut(10));

            religionlb2 = new JLabel();
            religionlb2.setText("Student Religion        :   " + religion);
            religionlb2.setFont(font);
            secondpnl.add(religionlb2);
            secondpnl.add(Box.createVerticalStrut(10));

            nationalitilb2 = new JLabel();
            nationalitilb2.setText("Student Nationality    :   " + nationality);
            nationalitilb2.setFont(font);
            secondpnl.add(nationalitilb2);
            secondpnl.add(Box.createVerticalStrut(10));

            //Third panel
            thirdpnl = new JPanel();
            thirdpnl.setBackground(Color.LIGHT_GRAY);
            BoxLayout blayout4 = new BoxLayout(thirdpnl, BoxLayout.Y_AXIS);
            thirdpnl.setLayout(blayout4);

            fathernamelb2 = new JLabel();
            fathernamelb2.setText("      Father's Name      :   " + fathername);
            fathernamelb2.setFont(font);
            thirdpnl.add(fathernamelb2);
            thirdpnl.add(Box.createVerticalStrut(10));

            meritiallb2 = new JLabel();
            meritiallb2.setText("      Marital Status      :   " + meritial);
            meritiallb2.setFont(font);
            thirdpnl.add(meritiallb2);
            thirdpnl.add(Box.createVerticalStrut(10));

            contactlb2 = new JLabel();
            contactlb2.setText("      Mobile Number    :   " + contact);
            contactlb2.setFont(font);
            thirdpnl.add(contactlb2);
            thirdpnl.add(Box.createVerticalStrut(10));

            genderlb2 = new JLabel();
            genderlb2.setText("      Student Gender    :   " + gender);
            genderlb2.setFont(font);
            thirdpnl.add(genderlb2);
            thirdpnl.add(Box.createVerticalStrut(10));

            heightlb2 = new JLabel();
            heightlb2.setText("      Student Height      :   " + height);
            heightlb2.setFont(font);
            thirdpnl.add(heightlb2);
            thirdpnl.add(Box.createVerticalStrut(10));

            weightlb2 = new JLabel();
            weightlb2.setText("      Student Weight     :   " + weight + "  Kg");
            weightlb2.setFont(font);
            thirdpnl.add(weightlb2);
            thirdpnl.add(Box.createVerticalStrut(10));

//adding panel
            pnl.add(firstpnl);
            pnl.add(secondpnl);
            pnl.add(thirdpnl);
            c.add(pnl);
            tablepnl = new JPanel();
            tablepnl.setBackground(Color.LIGHT_GRAY);
            tablepnl.setBounds(20, 320, 1320, 183);
            tablepnl.setLayout(null);

            //table String 
            int n = tbl.getRowCount();
            String[][] tbl2Row = new String[n][5];
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < 5; k++) {
                    tbl2Row[i][k] = tbl.getValueAt(i, k).toString();
                }
            }
            JTable tbl2 = new JTable(tbl2Row, cols);
            tbl2.setBackground(Color.LIGHT_GRAY);

            tbl2.setFont(f4);
            tbl2.setRowHeight(40);

            tbl2.sizeColumnsToFit(0);
            tbl2.setEnabled(false);
            JScrollPane scroll2 = new JScrollPane(tbl2);
            scroll2.setBounds(0, 0, 1320, 183);
            scroll2.setBackground(Color.LIGHT_GRAY);

            tablepnl.add(scroll2);
            c.add(tablepnl);
            signatturepnl = new JPanel();
            signatturepnl.setBackground(Color.LIGHT_GRAY);
            signatturepnl.setBounds(20, 503, 1320, 150);
            signatturepnl.setLayout(null);
            JLabel stext = new JLabel();
            stext.setBackground(Color.LIGHT_GRAY);
            stext.setBounds(620, 100, 180, 40);
            stext.setText("Signature");
            stext.setFont(f2);
            signatturepnl.add(stext);

            signaturelb2 = new JLabel();
            signaturelb2.setText(signaturetext);
            signaturelb2.setBounds(580, 60, 450, 50);
            signaturelb2.setFont(f5);
            signatturepnl.add(signaturelb2);

            c.add(signatturepnl);

            cancelbtn = new JButton("Cancel");
            cancelbtn.setBounds(0, 662, 140, 40);
            cancelbtn.setFont(f2);
            cancelbtn.setBackground(Color.LIGHT_GRAY);
            cancelbtn.setCursor(cursor);
            cancelbtn.setForeground(Color.RED);
            c.add(cancelbtn);

            savebtn = new JButton("Save");
            savebtn.setBounds(1250, 662, 90, 40);
            savebtn.setFont(f2);
            savebtn.setForeground(Color.BLUE);
            savebtn.setCursor(cursor);
            savebtn.setBackground(Color.LIGHT_GRAY);
            c.add(savebtn);
            cancelbtn.addActionListener(this);
            savebtn.addActionListener(this);

        } else if (e.getSource() == previousbtn) {
            clayout.previous(pnldemo);
        } else if (e.getSource() == nextbtn) {
            clayout.next(pnldemo);
        } else if (e.getSource() == cancelbtn) {
            System.exit(0);
        } else if (e.getSource() == savebtn) {
            JFileChooser file = new JFileChooser();
            file.add(pnl);
            file.add(signatturepnl);
            file.showSaveDialog(c);

        }

    }

}

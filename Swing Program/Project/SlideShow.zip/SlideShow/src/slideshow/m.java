package slideshow;

import javax.swing.JFrame;

public class m extends JFrame {

    public static void main(String[] args) {
        SlideShow frm = new SlideShow();
        frm.setVisible(true);
    }

}

package slideshow;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SlideShow extends JFrame implements ActionListener {

    Container c;
    Font f = new Font("Times New Roman", Font.BOLD, 24);
    JPanel pnl;
    JButton pbtn, nbtn;
    ImageIcon icon;
    JLabel lb;
    CardLayout cl;

    SlideShow() {
        this.setBounds(20, 29, 500, 600);
        this.setTitle("This is Slide Show");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);

        pnl = new JPanel();
        cl = new CardLayout();
        pnl.setLayout(cl);
        pnl.setBounds(20, 70, 440, 400);
        pnl.setBackground(Color.yellow);
        String[] str = {"1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg", "7.jpg"};
        for (String string : str) {

           // icon = new ImageIcon("src/slideshow/" + string);
            icon = new ImageIcon(getClass().getResource(string));
            Image img = icon.getImage();
            Image newimg = img.getScaledInstance(pnl.getWidth(), pnl.getHeight(), Image.SCALE_SMOOTH);
            icon = new ImageIcon(newimg);
            lb = new JLabel();
            lb.setIcon(icon);
            pnl.add(lb);
            c.add(pnl);

        }

        pbtn = new JButton("Previous");
        pbtn.setBounds(20, 480, 130, 50);
        pbtn.setFont(f);
        c.add(pbtn);
        nbtn = new JButton("Next");
        nbtn.setBounds(350, 480, 114, 50);
        nbtn.setFont(f);
        c.add(nbtn);

        pbtn.addActionListener(this);
        nbtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == pbtn) {
            cl.previous(pnl);
        } else if (e.getSource() == nbtn) {
            cl.next(pnl);
        }

    }

    public static void main(String[] args) {
        SlideShow frm = new SlideShow();
        frm.setVisible(true);

    }

}

package multiplicationtable;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Test extends JFrame {

    private Container c;
    private JLabel imglabel, textlabel;
    private ImageIcon img, icon;
    private Font f;
    private JTextField tf;
    private JButton button;
    private Cursor cursor, cursor2;
    private JTextArea ta;
    private JScrollPane scroll;

    Test() {
        this.initcomponent();
    }

    public void initcomponent() {
        icon = new ImageIcon(getClass().getResource("RR.png"));
        this.setTitle("Multiplication Table : ");
        this.setIconImage(icon.getImage());
        // this.setBounds(462, 20, 450, 700);
        this.setSize(450, 700);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.RED);

        cursor = new Cursor(Cursor.HAND_CURSOR);
        cursor2 = new Cursor(Cursor.TEXT_CURSOR);

        f = new Font("arial", Font.BOLD, 22);
        img = new ImageIcon(getClass().getResource("R.png"));
        imglabel = new JLabel(img);
        imglabel.setBounds(65, 15, img.getIconWidth(), img.getIconHeight());
        c.add(imglabel);
        textlabel = new JLabel("Enter Any Number : ");
        textlabel.setFont(f);
        textlabel.setBounds(65, 130, 240, 120);
        textlabel.setForeground(Color.BLUE);
        c.add(textlabel);

        tf = new JTextField();
        tf.setBounds(275, 173, 87, 40);
        tf.setBackground(Color.PINK);
        tf.setForeground(Color.BLACK);
        tf.setHorizontalAlignment(JTextField.CENTER);
        tf.setFont(f);
        tf.setCursor(cursor2);
        c.add(tf);

        button = new JButton("Clear");
        button.setBounds(275, 230, 87, 40);
        button.setFont(f);
        button.setCursor(cursor);
        c.add(button);

        ta = new JTextArea();

        ta.setFont(f);
        ta.setBackground(Color.MAGENTA);
        ta.setForeground(Color.BLUE);
        scroll = new JScrollPane(ta, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setBounds(65, 300, 297, 330);
        c.add(scroll);

        tf.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String number = tf.getText();
                ta.setText("");
                if (number.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "You did't put number. Please try again.", "Message", JOptionPane.INFORMATION_MESSAGE);
                } else {

                    int num = Integer.parseInt(tf.getText());
                    ta.append("\n");
                    for (int i = 1; i <= 10; i++) {
                        int result = num * i;

                        String r = String.valueOf(result);
                        String n = String.valueOf(num);
                        String I = String.valueOf(i);
                        ta.append("    " + n + " X " + i + " = " + r + "\n");
                    }
                }

            }
        });

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ta.setText("");
                tf.setText("");
            }
        });

    }

    public static void main(String[] args) {
        Test frame = new Test();
        frame.setVisible(true);

    }
}


package multiplicationtable;

public class Main {
    public static void main(String[] args) {
         Test frame = new Test();
        frame.setVisible(true);

    }
}

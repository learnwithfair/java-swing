package calculatorr;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class CalculatorR extends JFrame implements ActionListener {

    protected Container c;
    protected Dimension dmnsn;
    protected JLabel lb, lb2, lb3, lb4, lb5, imglb;
    protected Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
    protected JScrollPane scroll, scroll2;
    protected Font f1 = new Font("Times New Roman", Font.BOLD, 48);
    protected Font f2 = new Font("Times New Roman", Font.BOLD, 38);
    protected Font f3 = new Font("Times New Roman", Font.ROMAN_BASELINE, 38);
    protected JPanel pnl1, pnl2, pnl3, imgpnl;
    protected static int count = 0, s = 0, n = -1, j = 0, k = 1, m = 0, ans = 0;
    protected static double result = 0, r = 0, p = 1;
    protected JTextArea ta, ta2;
    protected ImageIcon icon, icon2;
    protected JButton btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9,
            btnadd, btnsub, btnmul, btndiv, btnrem, btnpoint, btnsqrt, btnsqr, btnresult, btnAC, clearbtn;
    protected GridLayout gl, gl2;
    protected FlowLayout fl = new FlowLayout(FlowLayout.CENTER);

    CalculatorR() {

        this.setBounds(20, 29, 526, 635);
        this.setTitle("Calculator");
        dmnsn = new Dimension(526, 635);
        this.setMinimumSize(dmnsn);
        //dmnsn = new Dimension(880, 635);
        //this.setMaximumSize(dmnsn);
        Rectangle rctngl = new Rectangle(280, 50, 850, 635);
        this.setMaximizedBounds(rctngl);
        this.setLocationRelativeTo(null);
        icon2 = new ImageIcon(getClass().getResource("RRR.png"));
        this.setIconImage(icon2.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        c = this.getContentPane();
        c.setLayout(gl);
        c.setBackground(Color.DARK_GRAY);
        pnl1 = new JPanel();
        gl = new GridLayout();
        pnl1.setLayout(gl);
        ta = new JTextArea("0");
        ta.setFont(f1);
        pnl1.add(ta);

        scroll = new JScrollPane(pnl1);
        scroll.setBounds(5, 10, 500, 90);
        c.add(scroll);

        pnl2 = new JPanel();
        pnl2.setCursor(cursor);
        pnl2.setBounds(5, 110, 500, 480);
        gl2 = new GridLayout(5, 5);
        pnl2.setLayout(gl2);

        btnrem = new JButton("%");
        btnrem.setFont(f3);
        btnrem.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnrem);
        btnsqrt = new JButton("√");
        btnsqrt.setFont(f3);
        btnsqrt.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnsqrt);
        btnsqr = new JButton("x^n");
        btnsqr.setFont(f3);
        btnsqr.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnsqr);
        btndiv = new JButton("÷");
        btndiv.setFont(f3);
        btndiv.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btndiv);

        btn7 = new JButton("7");
        btn7.setFont(f2);
        btn7.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn7);
        btn8 = new JButton("8");
        btn8.setFont(f2);
        btn8.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn8);
        btn9 = new JButton("9");
        btn9.setFont(f2);
        btn9.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn9);
        btnmul = new JButton("×");
        btnmul.setFont(f3);
        btnmul.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnmul);
        btn4 = new JButton("4");
        btn4.setFont(f2);
        btn4.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn4);
        btn5 = new JButton("5");
        btn5.setFont(f2);
        btn5.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn5);
        btn6 = new JButton("6");
        btn6.setFont(f2);
        btn6.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn6);
        btnsub = new JButton("–");
        btnsub.setFont(f3);
        btnsub.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnsub);
        btn1 = new JButton("1");
        btn1.setFont(f2);
        btn1.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn1);
        btn2 = new JButton("2");
        btn2.setFont(f2);
        btn2.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn2);
        btn3 = new JButton("3");
        btn3.setFont(f2);
        btn3.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn3);
        btnadd = new JButton("+");
        btnadd.setFont(f3);
        btnadd.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnadd);
        btnAC = new JButton("AC");
        btnAC.setFont(f2);
        btnAC.setForeground(Color.RED);
        btnAC.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnAC);
        btn0 = new JButton("0");
        btn0.setFont(f2);
        btn0.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btn0);
        btnpoint = new JButton(".");
        btnpoint.setFont(f2);
        btnpoint.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnpoint);
        btnresult = new JButton("=");
        btnresult.setFont(f3);
        btnresult.setBackground(Color.LIGHT_GRAY);
        pnl2.add(btnresult);
        c.add(pnl2);

        lb = new JLabel("History", JLabel.CENTER);
        lb.setForeground(Color.BLUE);
        lb.setBounds(511, 10, 320, 100);
        lb.setFont(f1);
        c.add(lb);

        pnl3 = new JPanel();
        pnl3.setLayout(gl);
        ta2 = new JTextArea();
        ta2.setFont(f1);
        ta2.setBackground(Color.LIGHT_GRAY);
        pnl3.add(ta2);
        scroll2 = new JScrollPane(pnl3);
        scroll2.setBounds(511, 112, 320, 420);
        c.add(scroll2);

        clearbtn = new JButton("Clear");
        clearbtn.setFont(f1);
        clearbtn.setCursor(cursor);
        clearbtn.setBounds(511, 530, 320, 60);
        clearbtn.setForeground(Color.RED);
        clearbtn.setBackground(Color.LIGHT_GRAY);
        c.add(clearbtn);

        imgpnl = new JPanel();
        imgpnl.setCursor(cursor);
        imgpnl.setBounds(835, 0, 525, 590);
        imgpnl.setLayout(fl);
        imgpnl.setBackground(Color.LIGHT_GRAY);
        lb2 = new JLabel("                                                                                                                                                                                                        ");
        lb2.setForeground(Color.black);
        lb2.setFont(f2);
        imgpnl.add(lb2);

        icon = new ImageIcon(getClass().getResource("RR.png"));
        imglb = new JLabel(icon);
        //imglb.setIcon();
        imgpnl.add(imglb);

        lb2 = new JLabel("                                                                                                                                                                                                        ");
        lb2.setForeground(Color.black);
        imgpnl.add(lb2);

        lb2 = new JLabel("Md Rahatul Islam");
        lb2.setForeground(Color.black);
        lb2.setFont(f2);
        imgpnl.add(lb2);
        lb2 = new JLabel("He is a Engineering student of Information and Communication Engineering (ICE) at PUST.");
        lb2.setForeground(Color.black);
        imgpnl.add(lb2);

        lb3 = new JLabel("                                            Gmail ID. rahatul.ice.09.pust@gmail.com                                        ");
        lb3.setForeground(Color.black);
        imgpnl.add(lb3);

        lb4 = new JLabel("                                                  Facebook ID.Md Rahatul Islam                                                  ");
        lb4.setForeground(Color.black);
        imgpnl.add(lb4);

        lb5 = new JLabel("                                                      Mobile NO.  01790-224950                                                 ");
        lb5.setForeground(Color.black);
        imgpnl.add(lb5);

        lb5 = new JLabel("                                                                   ® Thanks ®                                                              ");
        lb5.setForeground(Color.black);
        imgpnl.add(lb5);

        c.add(imgpnl);

        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        btn5.addActionListener(this);
        btn6.addActionListener(this);
        btn7.addActionListener(this);
        btn8.addActionListener(this);
        btn9.addActionListener(this);
        btn0.addActionListener(this);
        btnadd.addActionListener(this);
        btnsub.addActionListener(this);
        btnmul.addActionListener(this);
        btndiv.addActionListener(this);
        btnrem.addActionListener(this);
        btnresult.addActionListener(this);
        btnAC.addActionListener(this);
        btnpoint.addActionListener(this);
        btnsqrt.addActionListener(this);
        btnsqr.addActionListener(this);
        clearbtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                String str = ta2.getText();
                if (str.isEmpty()) {
                    JOptionPane.showMessageDialog(ta2, "History is Empty Please try again.");
                } else {
                    ta2.setText("");
                }

            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (count == 0) {
            ta.setText("");
        }
        count++;

        if (e.getSource() == btn0) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 0;
                s++;

            } else {
                r = r * 10 + 0;
            }

            ta.append("0");
            ta2.append("0");
        } else if (e.getSource() == btn1) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 1;
                s++;
            } else {
                r = r * 10 + 1;
            }
            ta.append("1");
            ta2.append("1");
        } else if (e.getSource() == btn2) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 2;
                s++;
            } else {
                r = r * 10 + 2;
            }
            ta.append("2");
            ta2.append("2");
        } else if (e.getSource() == btn3) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 3;
                s++;
            } else {
                r = r * 10 + 3;
            }
            ta.append("3");
            ta2.append("3");
        } else if (e.getSource() == btn4) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 4;
                s++;
            } else {
                r = r * 10 + 4;
            }
            ta.append("4");
            ta2.append("4");
        } else if (e.getSource() == btn5) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 5;
                s++;
            } else {
                r = r * 10 + 5;
            }
            ta.append("5");
            ta2.append("5");
        } else if (e.getSource() == btn6) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 6;
                s++;
            } else {
                r = r * 10 + 6;
            }
            ta.append("6");
            ta2.append("6");
        } else if (e.getSource() == btn7) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 7;
                s++;
            } else {
                r = r * 10 + 7;
            }
            ta.append("7");
            ta2.append("7");
        } else if (e.getSource() == btn8) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 8;
                s++;
            } else {
                r = r * 10 + 8;
            }
            ta.append("8");
            ta2.append("8");
        } else if (e.getSource() == btn9) {
            ans++;
            j++;
            if (k == 1) {
                k = 2;
            }
            if (s == 0) {
                r = 9;
                s++;
            } else {
                r = r * 10 + 9;
            }
            ta.append("9");
            ta2.append("9");
        } else if (e.getSource() == btnadd) {
            s = 0;
            n = 0;
            j = 0;
            m = k;
            k = 1;
            result = r;
            if (ans == -1) {
                ta.append("Ans + ");
                ta2.append("Ans + ");
                ans++;
            } else {
                ta.append(" + ");
                ta2.append(" + ");
            }

        } else if (e.getSource() == btnsub) {
            s = 0;
            n = 1;
            result = r;
            m = k;
            k = 1;
            if (ans == -1) {
                ta.append("Ans  – ");
                ta2.append("Ans  – ");
                ans++;
            } else {
                ta.append(" – ");
                ta2.append(" – ");
            }

        } else if (e.getSource() == btnmul) {
            s = 0;
            n = 2;
            result = r;
            m = k;
            k = 1;
            if (ans == -1) {
                ta.append("Ans  × ");
                ta2.append("Ans  × ");
                ans++;
            } else {
                ta.append(" × ");
                ta2.append(" × ");
            }
        } else if (e.getSource() == btndiv) {
            s = 0;
            n = 3;
            result = r;
            m = k;
            k = 1;
            if (ans == -1) {
                ta.append("Ans ÷ ");
                ta2.append("Ans ÷ ");
                ans++;

            } else {
                ta.append(" ÷ ");
                ta2.append(" ÷ ");
            }
        } else if (e.getSource() == btnrem) {
            s = 0;
            n = 4;
            result = r;
            m = k;
            k = 1;
            if (ans == -1) {
                ta.append("Ans % ");
                ta2.append("Ans % ");
                ans++;

            } else {
                ta.append(" % ");
                ta2.append(" % ");
            }
        } else if (e.getSource() == btnsqrt) {
            s = 0;
            n = 5;
            result = r;
            if (ans == -1) {
                ta.append("√Ans");
                ta2.append("√Ans");
                ans++;

            } else {
                ta.append(" √");
                ta2.append(" √");
            }
        } else if (e.getSource() == btnsqr) {
            s = 0;
            n = 6;
            result = r;
            m = k;
            k = 1;
            if (ans == -1) {
                ta.append("Ans^");
                ta2.append("Ans^");
                ans++;

            } else {
                ta.append("^");
                ta2.append("^");
            }
        } else if (e.getSource() == btnpoint) {
            ta.append(".");
            ta2.append(".");
        } else if (e.getSource() == btnresult) {
            s = 0;
            ans = -1;
            count = 0;
            switch (n) {
                case 0:
                    if (j > 0 && k == 2) {
                        result = result + r;
                        r = result;
                        ta.append(" = " + (int) result);
                        ta2.append(" = " + (int) result);
                        ta2.append("\n");

                    } else {
                        ta.append(" = " + p / 0);
                        ta2.append(" = " + p / 0);
                        ta2.append("\n");

                    }
                    break;
                case 1:
                    if (j > 0 && k == 2) {
                        result = result - r;
                        r = result;
                        ta.append(" = " + (int) result);
                        ta2.append(" = " + (int) result);
                        ta2.append("\n");

                    } else {
                        ta.append(" = " + p / 0);
                        ta2.append(" = " + p / 0);
                        ta2.append("\n");
                    }
                    break;
                case 2:
                    if (j > 0 && m == 2 && k == 2) {
                        result = result * r;
                        r = result;
                        ta.append(" = " + (int) result);
                        ta2.append(" = " + (int) result);
                        ta2.append("\n");

                    } else {
                        ta.append(" = " + p / 0);
                        ta2.append(" = " + p / 0);
                        ta2.append("\n");
                    }
                    break;
                case 3:
                    if (j > 0 && m == 2 && k == 2) {
                        double res = (result / r);
                        ta.append(" = " + (result / r));
                        ta2.append(" = " + (result / r));
                        ta2.append("\n");
                        r = res;
                    } else {
                        ta.append(" = " + p / 0);
                        ta2.append(" = " + p / 0);
                        ta2.append("\n");
                    }
                    break;
                case 4:
                    if (j > 0 && m == 2 && k == 2) {
                        result = (result % r);
                        ta.append(" = " + (int) (result % r));
                        ta2.append(" = " + (int) (result % r));
                        ta2.append("\n");
                        r = result;
                    } else {
                        ta.append(" = " + p / 0);
                        ta2.append(" = " + p / 0);
                        ta2.append("\n");
                    }
                    break;
                case 5:
                    if (j > 0) {
                        result = Math.sqrt(r);
                        ta.append(" = " + Math.sqrt(r));
                        ta2.append(" = " + Math.sqrt(r));
                        ta2.append("\n");

                        r = result;

                    } else {
                        ta.append(" = " + p / 0);
                        ta2.append(" = " + p / 0);
                        ta2.append("\n");
                    }

                    break;
                case 6:
                    p = 1;
                    if (j > 0 && m == 2 && k == 2) {

                        for (int i = 1; i <= r; i++) {
                            p = p * result;
                        }
                        ta.append(" = " + (int) p);
                        ta2.append(" = " + (int) p);
                        ta2.append("\n");
                        r = p;
                        p = 1;
                    } else {
                        ta.append(" = " + p / 0);
                        ta2.append(" = " + p / 0);
                        ta2.append("\n");
                    }
                    break;
                default:
                    ta.append(" = " + (int) r);
                    ta2.append(" = " + (int) r);
                    ta2.append("\n");
                    break;
            }
        } else if (e.getSource() == btnAC) {
            count = 0;
            ans = 0;
            s = 0;
            j = 0;
            r = 0;
            n = -1;
            k = 1;
            p = 1;
            m = 0;
            result = 0;
            ta.setText("0");
        }

    }

    public static void main(String[] args) {
        CalculatorR frm = new CalculatorR();
        frm.setVisible(true);
    }

}

package StudentsRegistrationForm;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class StudentsRegistrationForm extends JFrame implements ActionListener {

    protected Container c;
    protected Font f1 = new Font("Times New Roman", Font.BOLD, 32);
    protected Font f3 = new Font("Times New Roman", Font.BOLD + Font.ITALIC, 32);
    protected Font f2 = new Font("Times New Roman", Font.BOLD, 39);
    protected JTextField usernametf, passwordtf;
    protected JPasswordField password;
    protected JLabel usernamelb, passwordlb, heddinglb;
    protected JButton loginbtn, clearbtn, cancelbtn;
    protected Cursor corsur = new Cursor(Cursor.HAND_CURSOR);

    StudentsRegistrationForm() {

        this.setBounds(0, 0, 790, 600);
        this.setTitle("Student Registration Form");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        c = this.getContentPane();
        c.setBackground(Color.LIGHT_GRAY);
        c.setLayout(null);
        heddinglb = new JLabel(" \"*Please Login Student Registration Form*\"");
        heddinglb.setBounds(10, 0, 850, 90);
        heddinglb.setFont(f2);
        heddinglb.setForeground(Color.RED);
        c.add(heddinglb);
        usernamelb = new JLabel("Enter Your Username : ");
        usernamelb.setBounds(30, 170, 350, 60);
        usernamelb.setFont(f1);
        c.add(usernamelb);
        usernametf = new JTextField();
        usernametf.setBounds(390, 173, 350, 60);
        usernametf.setFont(f3);
        usernametf.setBackground(Color.LIGHT_GRAY);
        usernametf.setHorizontalAlignment(JTextField.CENTER);
        usernametf.setToolTipText("Username Hint's : rahatulislam");
        c.add(usernametf);
        passwordlb = new JLabel("Enter Your Password  : ");
        passwordlb.setBounds(30, 260, 350, 60);
        passwordlb.setFont(f1);
        c.add(passwordlb);
        password = new JPasswordField();
        password.setBounds(390, 263, 350, 60);
        password.setFont(f3);
        password.setBackground(Color.LIGHT_GRAY);
        password.setHorizontalAlignment(JTextField.CENTER);
        password.setToolTipText("Password Hint's : 12345678");
        c.add(password);

        cancelbtn = new JButton("Cancel");
        cancelbtn.setBounds(365, 430, 130, 60);
        cancelbtn.setBackground(Color.LIGHT_GRAY);
        cancelbtn.setCursor(corsur);
        cancelbtn.setForeground(Color.RED);
        cancelbtn.setFont(f1);
        c.add(cancelbtn);
        clearbtn = new JButton("Clear");
        clearbtn.setBounds(510, 430, 120, 60);
        clearbtn.setBackground(Color.LIGHT_GRAY);
        clearbtn.setCursor(corsur);
        clearbtn.setForeground(Color.YELLOW);
        clearbtn.setFont(f1);
        c.add(clearbtn);
        loginbtn = new JButton("Login");
        loginbtn.setBounds(645, 430, 120, 60);
        loginbtn.setBackground(Color.LIGHT_GRAY);
        loginbtn.setCursor(corsur);
        loginbtn.setForeground(Color.CYAN);
        loginbtn.setFont(f1);
        c.add(loginbtn);
        cancelbtn.addActionListener(this);
        clearbtn.addActionListener(this);
        loginbtn.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == cancelbtn) {
            System.exit(0);
        } else if (e.getSource() == clearbtn) {
            String value1 = usernametf.getText();
            String value2 = password.getText();
            if (value1.isEmpty() && value2.isEmpty()) {
                JOptionPane.showMessageDialog(c, "This Username & Password are Empty.Please Try again", "Warning Message.", JOptionPane.WARNING_MESSAGE);
            } else {
                usernametf.setText("");
                password.setText("");
            }

        } else if (e.getSource() == loginbtn) {
            String value1 = usernametf.getText();
            String value2 = password.getText();
            if (value1.isEmpty() || value2.isEmpty()) {
                if (value1.isEmpty()) {
                    JOptionPane.showMessageDialog(password, "This Username is Empty.Please Try again", "Warning Message.", JOptionPane.ERROR_MESSAGE);
                } else if (value2.isEmpty()) {
                    JOptionPane.showMessageDialog(usernametf, "This Password is Empty.Please Try again", "Warning Message.", JOptionPane.ERROR_MESSAGE);
                }

            } else if (value1.equals("@rahatulislam") && value2.equals("12345678")) {
                JOptionPane.showMessageDialog(c, "You have Succesfully Login.", "Information Message.", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(c, "Welcome to Student Registration Form.", "Welcome Message.", JOptionPane.INFORMATION_MESSAGE);
                Resitration frm = new Resitration();
                frm.setVisible(true);

            } else {

                if (value1.equals("@rahatulislam")) {
                    JOptionPane.showMessageDialog(usernametf, "This Password is Incorrect. Please try again.", "Error Message.", JOptionPane.ERROR_MESSAGE);
                } else if (value2.equals("12345678")) {
                    JOptionPane.showMessageDialog(password, "This Username is Incorrect. Please try again.", "Error Message.", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(c, "This Username & Password are Incorrect. Please try again.", "Error Message.", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    public static void main(String[] args) {
        StudentsRegistrationForm frm = new StudentsRegistrationForm();
        frm.setVisible(true);
    }

}

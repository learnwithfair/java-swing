package StudentsRegistrationForm;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;

public class show extends JFrame {

    protected Container c;

    show() {
        this.setBounds(0, 0, 1350, 700);
        this.setTitle("This is Result of Student Registration Form");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.LIGHT_GRAY);

    }

    public static void main(String[] args) {
        show frm = new show();
        frm.setVisible(true);
    }

}

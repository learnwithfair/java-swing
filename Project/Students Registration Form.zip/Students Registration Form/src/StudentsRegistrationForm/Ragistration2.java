package StudentsRegistrationForm;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Ragistration2 extends JFrame implements ActionListener {

    protected Container c;
    protected JPanel pnl;
    protected int numberOfRow = -1;
    protected JTable tbl;
    protected Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
    protected JButton deletebtn, deleteallbtn, updatebtn, addbtn, previousbtn, showbtn, clearbtn, signaturebtn;
    protected JTextField institudetf, gpatf;
    protected DefaultTableModel model;
    protected JComboBox examinationcbox, boardcbox, yearcbox;
    protected JLabel educationlb, examinationlb, institudelb, yearlb, gpalb, boardlb, signaturelb;
    protected Font f1 = new Font("Times New Roman", Font.BOLD, 48);
    protected Font f2 = new Font("Times New Roman", Font.BOLD, 24);
    protected Font f3 = new Font("Times New Roman", Font.BOLD, 18);
    protected Font f4 = new Font("Times New Roman", Font.BOLD + Font.ITALIC, 24);
    protected String[] cols = {"Name of Institution", "Examination", "Board", "Passing Year", "GPA / CGP"};
    protected String[] row = new String[5];
    protected String[] strname = new String[5];

    Ragistration2() {
        this.setBounds(0, 0, 1350, 700);
        this.setTitle("Student Registration Form 2");
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.LIGHT_GRAY);

        educationlb = new JLabel();
        educationlb.setText("Educational Background : ");
        educationlb.setFont(f1);
        educationlb.setBounds(15, 0, 580, 90);
        c.add(educationlb);
        pnl = new JPanel();
        pnl.setLayout(null);
        pnl.setBackground(Color.YELLOW);
        pnl.setBounds(20, 80, 1320, 650);

        examinationlb = new JLabel("Select Examination     : ");
        examinationlb.setBounds(0, 20, 250, 50);
        examinationlb.setFont(f2);
        pnl.add(examinationlb);
        String[] str = {"                P.S.C", "                J.S.C", "                S.S.C",
            "                H.S.C", "                B.Sc", "                B.A", "                B.B.A", "                M.A", "                M.S.C", "                Other"};
        examinationcbox = new JComboBox(str);
        examinationcbox.setBounds(260, 20, 350, 50);
        examinationcbox.setSelectedIndex(4);
        examinationcbox.setBackground(Color.LIGHT_GRAY);
        examinationcbox.setFont(f2);
        pnl.add(examinationcbox);

        boardlb = new JLabel("Select Exam Borad     : ");
        boardlb.setBounds(700, 20, 250, 50);
        boardlb.setFont(f2);
        pnl.add(boardlb);
        String[] boardname = {"             Borishal", "             Chittagone", "              Comilla", "               Dhaka",
            "             Dinajpur", "                Jasor", "             Madrasah", "             Rajshahi", "               Seylet", "                Other"};
        boardcbox = new JComboBox(boardname);
        boardcbox.setBounds(960, 20, 350, 50);
        boardcbox.setSelectedIndex(6);
        boardcbox.setBackground(Color.LIGHT_GRAY);
        boardcbox.setFont(f2);
        pnl.add(boardcbox);

        institudelb = new JLabel("Enter Name of Institution     : ");
        institudelb.setBounds(130, 90, 350, 50);
        institudelb.setFont(f2);
        pnl.add(institudelb);

        institudetf = new JTextField("    ");
        institudetf.setBounds(490, 90, 670, 50);
        institudetf.setBackground(Color.LIGHT_GRAY);
        institudetf.setToolTipText("Institude Name Hint's : Pabna University of Science and Tecnology''");
        institudetf.setSelectionColor(Color.RED);
        institudetf.setHorizontalAlignment(JTextField.CENTER);
        institudetf.setFont(f2);
        pnl.add(institudetf);

        yearlb = new JLabel("Select Passing Year    : ");
        yearlb.setBounds(0, 160, 250, 50);
        yearlb.setFont(f2);
        pnl.add(yearlb);
        String[] yearname = {"                2030", "                2029", "                2028", "                2027",
            "                2026", "                2025", "                2024", "                2023", "                2022",
            "                2021", "                2020", "                2019", "                2018", "                2017",
            "                2016", "                2015", "                2014", "                2013", "                2012",
            "                2011", "                2010", "                2009", "                2008", "                2007", "                2006",
            "                2005", "                2004", "                2003", "                2002", "                2001", "                2000",
            "                1999", "                1998", "                1997", "                1996", "                1995", "                1994",
            "                1993", "                1992", "                1991", "                1990"};
        yearcbox = new JComboBox(yearname);
        yearcbox.setBounds(260, 160, 350, 50);
        yearcbox.setSelectedIndex(10);
        yearcbox.setBackground(Color.LIGHT_GRAY);
        yearcbox.setFont(f2);
        pnl.add(yearcbox);

        gpalb = new JLabel("Enter GPA / CGPA    : ");
        gpalb.setBounds(700, 160, 350, 50);
        gpalb.setFont(f2);
        pnl.add(gpalb);

        gpatf = new JTextField("                 ");
        gpatf.setBounds(960, 160, 350, 50);
        gpatf.setBackground(Color.LIGHT_GRAY);
        gpatf.setToolTipText("GPA / CGPA Hint's : 5.00 / 3.88");
        gpatf.setSelectionColor(Color.RED);
        gpatf.setFont(f2);
        pnl.add(gpatf);

        deleteallbtn = new JButton("Delete All");
        deleteallbtn.setBackground(Color.LIGHT_GRAY);
        deleteallbtn.setBounds(20, 230, 190, 50);
        deleteallbtn.setCursor(cursor);
        deleteallbtn.setFont(f2);
        deleteallbtn.setForeground(Color.RED);
        pnl.add(deleteallbtn);

        deletebtn = new JButton("Delete");
        deletebtn.setBackground(Color.LIGHT_GRAY);
        deletebtn.setBounds(290, 230, 190, 50);
        deletebtn.setCursor(cursor);
        deletebtn.setFont(f2);
        deletebtn.setForeground(Color.RED);
        pnl.add(deletebtn);
        clearbtn = new JButton("Clear");
        clearbtn.setBackground(Color.LIGHT_GRAY);
        clearbtn.setBounds(560, 230, 190, 50);
        clearbtn.setCursor(cursor);
        clearbtn.setFont(f2);
        clearbtn.setForeground(Color.RED);
        pnl.add(clearbtn);
        updatebtn = new JButton("Update");
        updatebtn.setBackground(Color.LIGHT_GRAY);
        updatebtn.setBounds(830, 230, 190, 50);
        updatebtn.setCursor(cursor);
        updatebtn.setFont(f2);
        updatebtn.setForeground(Color.RED);
        pnl.add(updatebtn);

        addbtn = new JButton("Add");
        addbtn.setBackground(Color.LIGHT_GRAY);
        addbtn.setBounds(1100, 230, 190, 50);
        addbtn.setCursor(cursor);
        addbtn.setFont(f2);
        addbtn.setForeground(Color.RED);
        pnl.add(addbtn);

        model = new DefaultTableModel();
        model.setColumnIdentifiers(cols);
        tbl = new JTable(model);
        tbl.setBackground(Color.LIGHT_GRAY);
        tbl.setFont(f3);
        tbl.setSelectionBackground(Color.GREEN);
        tbl.setRowHeight(40);

        tbl.sizeColumnsToFit(0);
        // tbl.setRowSelectionAllowed(true);
        //tbl.setColumnSelectionAllowed(false);
        tbl.setSelectionForeground(Color.RED);

        JScrollPane scroll = new JScrollPane(tbl);
        scroll.setBounds(0, 300, 1320, 200);
        pnl.add(scroll);

        c.add(pnl);
        tbl.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                numberOfRow = tbl.getSelectedRow();
                String institutiontext = model.getValueAt(numberOfRow, 0).toString();
                String examinationtext = model.getValueAt(numberOfRow, 1).toString();
                String boardtext = model.getValueAt(numberOfRow, 2).toString();
                String passingyeartext = model.getValueAt(numberOfRow, 3).toString();
                String gpatext = model.getValueAt(numberOfRow, 4).toString();
                examinationcbox.setSelectedItem(examinationtext);
                boardcbox.setSelectedItem(boardtext);
                institudetf.setText(institutiontext);
                yearcbox.setSelectedItem(passingyeartext);
                gpatf.setText(gpatext);

            }
        });

        previousbtn = new JButton("Previous");
        previousbtn.setBounds(0, 570, 180, 50);
        previousbtn.setFont(f3);
        previousbtn.setBackground(Color.LIGHT_GRAY);
        previousbtn.setCursor(cursor);
        previousbtn.setForeground(Color.RED);
        pnl.add(previousbtn);

        signaturebtn = new JButton("Set Signature");
        signaturebtn.setBounds(570, 570, 180, 50);
        signaturebtn.setFont(f2);
        signaturebtn.setBackground(Color.LIGHT_GRAY);
        signaturebtn.setCursor(cursor);
        pnl.add(signaturebtn);

        signaturelb = new JLabel("_________________");
        signaturelb.setBounds(560, 510, 450, 50);
        signaturelb.setFont(f4);
        pnl.add(signaturelb);

        showbtn = new JButton("Show");
        showbtn.setBounds(1135, 570, 180, 50);
        showbtn.setFont(f2);
        showbtn.setBackground(Color.LIGHT_GRAY);
        showbtn.setCursor(cursor);
        showbtn.setForeground(Color.BLUE);
        pnl.add(showbtn);

        addbtn.addActionListener(this);
        clearbtn.addActionListener(this);
        deletebtn.addActionListener(this);
        deleteallbtn.addActionListener(this);
        updatebtn.addActionListener(this);
        signaturebtn.addActionListener(this);
        showbtn.addActionListener(this);
        previousbtn.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addbtn) {

            row[0] = institudetf.getText();
            row[1] = examinationcbox.getSelectedItem().toString();
            row[2] = boardcbox.getSelectedItem().toString();
            row[3] = yearcbox.getSelectedItem().toString();
            row[4] = gpatf.getText();
            model.addRow(row);
        } else if (e.getSource() == clearbtn) {
            examinationcbox.setSelectedIndex(4);
            boardcbox.setSelectedIndex(6);
            institudetf.setText("    ");
            yearcbox.setSelectedIndex(10);
            gpatf.setText("                 ");
        } else if (e.getSource() == updatebtn) {
            int r1 = model.getRowCount();
            if (r1 <= 0) {
                JOptionPane.showMessageDialog(tbl, "This Table is Empty. Please at first Insert Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
            } else if (numberOfRow == -1) {
                JOptionPane.showMessageDialog(tbl, "You have not Selected Row. Please at first Select Row then Try Again.", "Error Message", JOptionPane.ERROR_MESSAGE);
            } else {
                strname[0] = institudetf.getText();
                strname[1] = examinationcbox.getSelectedItem().toString();
                strname[2] = boardcbox.getSelectedItem().toString();
                strname[3] = yearcbox.getSelectedItem().toString();
                strname[4] = gpatf.getText();
                tbl.setValueAt(strname[0], numberOfRow, 0);
                tbl.setValueAt(strname[1], numberOfRow, 1);
                tbl.setValueAt(strname[2], numberOfRow, 2);
                tbl.setValueAt(strname[3], numberOfRow, 3);
                tbl.setValueAt(strname[4], numberOfRow, 4);
            }
        } else if (e.getSource() == deletebtn) {
            int r2 = 0;
            r2 = model.getRowCount();
            if (r2 < 1) {
                JOptionPane.showMessageDialog(tbl, "This Table is Empty. Please at first Insert Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
            } else if (numberOfRow == -1) {
                int[] rowscount = tbl.getSelectedRows();
                Arrays.sort(rowscount);
                int n = rowscount.length;
                if (n == 0) {
                    JOptionPane.showMessageDialog(tbl, "You have not Selected Row. Please at first Select Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
                } else {
                    for (int i = n - 1; i >= 0; i--) {
                        model.removeRow(rowscount[i]);
                    }
                    numberOfRow = -1;
                }

            } else {
                int[] rowscount2 = tbl.getSelectedRows();
                Arrays.sort(rowscount2);
                int n2 = rowscount2.length;
                for (int i = n2 - 1; i >= 0; i--) {
                    model.removeRow(rowscount2[i]);
                }
                numberOfRow = -1;
            }
        } else if (e.getSource() == deleteallbtn) {
            int r2 = 0;
            r2 = model.getRowCount();
            if (r2 < 1) {
                JOptionPane.showMessageDialog(tbl, "This Table is Empty. Please at first Insert Row then Try Again.", "Warning Message", JOptionPane.ERROR_MESSAGE);
            } else {
                for (int i = r2 - 1; i >= 0; i--) {
                    model.removeRow(i);

                }
            }
        } else if (e.getSource() == signaturebtn) {
            String signature = JOptionPane.showInputDialog(tbl, "Enter Your Signature", "Signature Input", JOptionPane.INFORMATION_MESSAGE);
            if (signature.isEmpty()) {
                JOptionPane.showMessageDialog(tbl, "You have no Signature Please Try Again.", "Error Message", JOptionPane.ERROR_MESSAGE);
            } else {
                signaturelb.setText(signature);
            }
        } else if (e.getSource() == showbtn) {
            show frm = new show();
            frm.setVisible(true);
        } else if (e.getSource() == previousbtn) {
            Resitration frm = new Resitration();
            frm.setVisible(true);
        }

    }

    public static void main(String[] args) {
        Ragistration2 frm = new Ragistration2();
        frm.setVisible(true);
    }

}

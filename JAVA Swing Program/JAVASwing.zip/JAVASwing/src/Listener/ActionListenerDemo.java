package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class ActionListenerDemo extends JFrame implements ActionListener {

    Container c;
    Font f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
    JButton lbtn, cbtn;
    JLabel tfl, pfl;
    JTextField tf;
    JPasswordField pf;

    ActionListenerDemo() {
        this.setTitle("This is ActionListener");
        this.setBounds(20, 29, 600, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);

        tfl = new JLabel();
        tfl.setText("Enter your name ");
        tfl.setBounds(10, 20, 200, 50);
        tfl.setForeground(Color.blue);
        tfl.setFont(f);
        c.add(tfl);
        tf = new JTextField();
        tf.setBounds(210, 20, 200, 50);
        tf.setHorizontalAlignment(JTextField.CENTER);
        tf.setForeground(Color.red);
        tf.setFont(f);
        c.add(tf);

        pfl = new JLabel();
        pfl.setText("Enter Password ");
        pfl.setBounds(10, 80, 200, 50);
        pfl.setForeground(Color.blue);
        pfl.setFont(f);
        c.add(pfl);
        pf = new JPasswordField();
        pf.setBounds(210, 80, 200, 50);
        pf.setHorizontalAlignment(JPasswordField.CENTER);

        pf.setFont(f);
        c.add(pf);

        lbtn = new JButton("Login");
        lbtn.setBounds(330, 250, 120, 60);
        lbtn.setForeground(Color.green);
        lbtn.setFont(f);
        c.add(lbtn);

        cbtn = new JButton("Cencel");
        cbtn.setForeground(Color.red);
        cbtn.setBounds(180, 250, 120, 60);
        cbtn.setFont(f);
        c.add(cbtn);
        lbtn.addActionListener(this);
        cbtn.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String str = tf.getText().toString();
        String str2 = pf.getText().toString();
        //String str2 = pf.getPassword().toString();

        if (str.isEmpty() || str2.isEmpty()) {
            if (e.getSource() == cbtn) {
                System.exit(0);
            } else {
                JOptionPane.showMessageDialog(null, " Please at First Insert the Value", "Worning Message", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            if (e.getSource() == cbtn) {
                System.exit(0);
            } else if (e.getSource() == lbtn) {
                JOptionPane.showMessageDialog(null, str + " Welcome to Java Swing", "This is Login Form", JOptionPane.INFORMATION_MESSAGE);
                tf.setText("");
                pf.setText("");
            }
        }
    }

    public static void main(String[] args) {
        ActionListenerDemo frm = new ActionListenerDemo();
        frm.setVisible(true);
    }
}

package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JFrame;

public class WindowListenerDemo extends JFrame implements WindowListener {
    Container c;
    WindowListenerDemo() {
        this.setBounds(20, 29, 700, 500);
        this.setTitle("This is Mouse Listener");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);
        this.addWindowListener(this);
    }
    @Override
    public void windowOpened(WindowEvent we) {
        System.out.println("Window Opened");
    }
    @Override
    public void windowClosing(WindowEvent we) {
        System.out.println("Window Closing");
    }
    @Override
    public void windowClosed(WindowEvent we) {
        System.out.println("Window Closed");
    }
    @Override
    public void windowIconified(WindowEvent we) {
        System.out.println("Window Iconified");
    }
    @Override
    public void windowDeiconified(WindowEvent we) {
        System.out.println("Window Deiconified");
    }
    @Override
    public void windowActivated(WindowEvent we) {
        System.out.println("Window Activated");
    }
    @Override
    public void windowDeactivated(WindowEvent we) {
        System.out.println("Window Deactivated");
    }
    public static void main(String[] args) {
        WindowListenerDemo frm = new WindowListenerDemo();
        frm.setVisible(true);
    }
}

package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class FocusListenerDemo extends JFrame implements FocusListener {
    Container c;
    JTextArea ta;
    JButton btn;
    Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    FocusListenerDemo() {
        this.setBounds(20, 29, 700, 500);
        this.setTitle("This is Mouse Listener");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);
        btn = new JButton("Click");
        btn.setFont(f);
        btn.setBounds(20, 120, 120, 50);
        c.add(btn);
        ta = new JTextArea();
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setFont(f);
        JScrollPane scroll1 = new JScrollPane(ta);
        scroll1.setBounds(180, 50, 300, 200);
        c.add(scroll1);
        btn.addFocusListener(this);
    }
    @Override
    public void focusGained(FocusEvent fe) {
        ta.append("Focus Gained\n");
    }
    @Override
    public void focusLost(FocusEvent fe) {
        ta.append("Focus Lost\n");
    }
    public static void main(String[] args) {
        FocusListenerDemo frm = new FocusListenerDemo();
        frm.setVisible(true);
    }
}

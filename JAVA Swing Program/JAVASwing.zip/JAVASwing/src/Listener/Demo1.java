package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Demo1 extends JFrame implements ActionListener {

    JButton btn = new JButton("Close");
    Container c;
    Cursor corsor = new Cursor(Cursor.HAND_CURSOR);

    Demo1() {

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        btn.setBounds(20, 29, 200, 200);
        btn.setCursor(corsor);
        c.add(btn);
        btn.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.exit(0);
    }

    public static void main(String[] args) {
        Demo1 frm = new Demo1();
        frm.setVisible(true);
        frm.setBounds(20, 29, 400, 500);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}

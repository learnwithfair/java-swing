package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Demo3 extends JFrame {

    Demo3() {
        JButton btn = new JButton("Close");
        Container c;
        Cursor corsor = new Cursor(Cursor.HAND_CURSOR);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        btn.setBounds(20, 29, 200, 200);
        btn.setCursor(corsor);
        c.add(btn);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        Demo3 frm = new Demo3();
        frm.setVisible(true);
        frm.setBounds(20, 29, 400, 500);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

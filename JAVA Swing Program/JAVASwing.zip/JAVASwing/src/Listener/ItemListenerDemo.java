package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ItemListenerDemo extends JFrame {
    Container c;
    Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    JLabel lb;
    String[] str = {"C", "C++", "Java"};
    ItemListenerDemo() {
        this.setTitle("This is Item Listener");
        this.setBounds(20, 29, 400, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);
        JComboBox box = new JComboBox(str);
        box.setBounds(50, 50, 200, 50);
        box.setFont(f);
        box.addItem("Java Swing");
        box.addItem("Phython");
        box.addItem("PHP");
        box.setSelectedItem("Java Swing");
        box.setEditable(true);
        c.add(box);
        lb = new JLabel("You are Selected : Java Swing");
        lb.setBounds(20, 110, 400, 50);
        lb.setForeground(Color.red);
        lb.setFont(f);
        c.add(lb);
        box.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent ie) {
                lb.setText("You are Selected : " + ie.getItem());
            }
        });
    }
    public static void main(String[] args) {
        ItemListenerDemo frm = new ItemListenerDemo();
        frm.setVisible(true);
    }
}

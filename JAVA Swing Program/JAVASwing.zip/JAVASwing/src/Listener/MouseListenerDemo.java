package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MouseListenerDemo extends JFrame implements MouseListener {
    Container c;
    JTextField tf;
    JTextArea ta;
    Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    MouseListenerDemo() {
        this.setBounds(20, 29, 400, 500);
        this.setTitle("This is Mouse Listener");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);
        tf = new JTextField();
        tf.setFont(f);
        tf.setBounds(20, 29, 160, 50);
        c.add(tf);
        ta = new JTextArea();
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setFont(f);
        JScrollPane scroll = new JScrollPane(ta);
        scroll.setBounds(20, 90, 300, 200);
        c.add(scroll);
        tf.addMouseListener(this);
    }
    @Override
    public void mouseClicked(MouseEvent me) {
        ta.append("Mouse Clicked\n");
    }
    @Override
    public void mousePressed(MouseEvent me) {
        ta.append("Mouse Pressed\n");
    }
    @Override
    public void mouseReleased(MouseEvent me) {
        ta.append("Mouse Released\n");
    }
    @Override
    public void mouseEntered(MouseEvent me) {
        ta.append("Mouse Entered\n");
    }
    @Override
    public void mouseExited(MouseEvent me) {
        ta.append("Mouse Exited\n");
    }
    public static void main(String[] args) {
        MouseListenerDemo frm = new MouseListenerDemo();
        frm.setVisible(true);
    }
}

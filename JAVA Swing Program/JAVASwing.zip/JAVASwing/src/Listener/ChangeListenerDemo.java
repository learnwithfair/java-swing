package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ChangeListenerDemo extends JFrame implements ChangeListener {
    Container c;
    Font f = new Font("arial", Font.BOLD, 24);
    JLabel lb1, lb2, lb3, p;
    JTextField tf1, tf2, tf3;
    JPanel pnl;
    JSlider s1, s2, s3;
    ChangeListenerDemo() {
        this.setBounds(20, 29, 900, 600);
        this.setTitle("This is Change Listener");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        lb1 = new JLabel("Red     :");
        lb1.setBounds(20, 70, 90, 50);
        lb1.setForeground(Color.red);
        lb1.setFont(f);
        c.add(lb1);
        s1 = new JSlider(0, 255, 0);
        s1.setBounds(120, 74, 300, 50);
        s1.setBackground(Color.magenta);
        s1.setForeground(Color.red);
        s1.setMajorTickSpacing(25);
        s1.setMinorTickSpacing(5);
        s1.setPaintTicks(true);
        s1.setPaintLabels(true);
        c.add(s1);
        tf1 = new JTextField();
        tf1.setBounds(430, 74, 80, 50);
        tf1.setFont(f);
        tf1.setForeground(Color.red);
        tf1.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf1);
        lb2 = new JLabel("Blue    :");
        lb2.setBounds(20, 140, 90, 50);
        lb2.setForeground(Color.BLUE);
        lb2.setFont(f);
        c.add(lb2);
        s2 = new JSlider(0, 255, 10);
        s2.setBounds(120, 144, 300, 50);
        s2.setMinorTickSpacing(1);
        s2.setMajorTickSpacing(5);
        s2.setPaintTicks(true);
        s2.setBackground(Color.magenta);
        s2.setForeground(Color.BLUE);
        s2.setMajorTickSpacing(25);
        s2.setMinorTickSpacing(5);
        s2.setPaintTicks(true);
        s2.setPaintLabels(true);
        c.add(s2);
        tf2 = new JTextField();
        tf2.setBounds(430, 144, 80, 50);
        tf2.setFont(f);
        tf2.setForeground(Color.blue);
        tf2.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf2);
        lb3 = new JLabel("Green :");
        lb3.setBounds(20, 210, 90, 50);
        lb3.setForeground(Color.GREEN);
        lb3.setFont(f);
        c.add(lb3);
        s3 = new JSlider(0, 255, 20);
        s3.setBounds(120, 213, 300, 50);
        s3.setBackground(Color.magenta);
        s3.setForeground(Color.GREEN);
        s3.setMajorTickSpacing(25);
        s3.setMinorTickSpacing(5);
        s3.setPaintTicks(true);
        s3.setPaintLabels(true);
        c.add(s3);
        tf3 = new JTextField();
        tf3.setBounds(430, 213, 80, 50);
        tf3.setFont(f);
        tf3.setForeground(Color.green);
        tf3.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf3);
        pnl = new JPanel();
        pnl.setBounds(550, 70, 300, 200);
        pnl.setBackground(Color.ORANGE);
        c.add(pnl);
        p = new JLabel("Preview");
        p.setBounds(660, 270, 90, 50);
        p.setFont(f);
        c.add(p);
        s1.addChangeListener(this);
        s2.addChangeListener(this);
        s3.addChangeListener(this);
    }

    @Override
    public void stateChanged(ChangeEvent ce) {
        int red = s1.getValue();
        int blue = s2.getValue();
        int green = s3.getValue();
        tf1.setText("" + red);
        tf2.setText("" + blue);
        tf3.setText("" + green);
        Color color = new Color(red, green, blue);
        pnl.setBackground(color);
    }
    public static void main(String[] args) {
        ChangeListenerDemo frm = new ChangeListenerDemo();
        frm.setVisible(true);
    }
}

package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class MouseMotionListenerDemo extends JFrame implements MouseMotionListener {
    Container c;
    JTextArea ta1, ta2;
    Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    MouseMotionListenerDemo() {
        this.setBounds(20, 29, 700, 500);
        this.setTitle("This is Mouse Listener");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);
        ta1 = new JTextArea();
        ta1.setLineWrap(true);
        ta1.setWrapStyleWord(true);
        ta1.setFont(f);
        JScrollPane scroll1 = new JScrollPane(ta1);
        scroll1.setBounds(20, 90, 300, 200);
        c.add(scroll1);
        ta2 = new JTextArea();
        ta2.setLineWrap(true);
        ta2.setWrapStyleWord(true);
        ta2.setFont(f);
        ta2.setBackground(Color.magenta);
        JScrollPane scroll2 = new JScrollPane(ta2);
        scroll2.setBounds(330, 90, 300, 200);
        c.add(scroll2);
        ta1.addMouseMotionListener(this);
    }
    @Override
    public void mouseDragged(MouseEvent me) {
        ta2.append("Mouse Dragged\n");
    }
    @Override
    public void mouseMoved(MouseEvent me) {
        ta2.append("Mouse Moved\n");
    }
    public static void main(String[] args) {
        MouseMotionListenerDemo frm = new MouseMotionListenerDemo();
        frm.setVisible(true);
    }
}

package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class KeyListenerDemo extends JFrame implements KeyListener, ActionListener {

    Container c;
    JTextField tf;
    JTextArea ta;
    JLabel lb, tlb, alb, elb, ilb, olb, ulb, clb;
    Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    JButton cencel, clear;
    Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
    int total = 0, atotal = 0, etotal = 0, itotal = 0, ototal = 0, utotal = 0, ctotal = 0;

    KeyListenerDemo() {
        this.setBounds(20, 29, 650, 580);
        this.setLocationRelativeTo(null);
        this.setTitle("This is Key Listener");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);

        lb = new JLabel();
        lb.setBounds(20, 10, 300, 45);
        lb.setText("Enter your Comments : ");
        lb.setFont(f);
        lb.setForeground(Color.blue);
        c.add(lb);
        ta = new JTextArea();

        ta.setBackground(Color.pink);
        ta.setFont(f);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(ta);
        scroll.setBounds(20, 50, 300, 300);
        c.add(scroll);

        tlb = new JLabel();
        tlb.setBounds(330, 60, 400, 45);
        tlb.setText("Total number of Vowel : 0");
        tlb.setFont(f);
        tlb.setForeground(Color.red);
        c.add(tlb);

        alb = new JLabel();
        alb.setBounds(330, 115, 300, 45);
        alb.setText("Total A  : 0");
        alb.setFont(f);
        alb.setForeground(Color.red);
        c.add(alb);
        elb = new JLabel();
        elb.setBounds(330, 170, 300, 45);
        elb.setText("Total E  : 0");
        elb.setFont(f);
        elb.setForeground(Color.red);
        c.add(elb);
        ilb = new JLabel();
        ilb.setBounds(330, 215, 300, 45);
        ilb.setText("Total I   : 0");
        ilb.setFont(f);
        ilb.setForeground(Color.red);
        c.add(ilb);
        olb = new JLabel();
        olb.setBounds(330, 265, 300, 45);
        olb.setText("Total O : 0");
        olb.setFont(f);
        olb.setForeground(Color.red);
        c.add(olb);
        ulb = new JLabel();
        ulb.setBounds(330, 315, 300, 45);
        ulb.setText("Total U : 0");
        ulb.setFont(f);
        ulb.setForeground(Color.red);
        c.add(ulb);

        clb = new JLabel();
        clb.setBounds(20, 420, 400, 45);
        clb.setText("Total Character Count :  0");
        clb.setFont(f);
        clb.setForeground(Color.red);
        c.add(clb);
        clear = new JButton("Clear");
        clear.setBounds(200, 355, 120, 50);
        clear.setFont(f);
        clear.setForeground(Color.red);
        clear.setCursor(cursor);
        c.add(clear);
        cencel = new JButton("Cencel");
        cencel.setBounds(450, 450, 120, 50);
        cencel.setFont(f);
        cencel.setForeground(Color.red);
        cencel.setCursor(cursor);
        c.add(cencel);
        ta.addKeyListener(this);
        cencel.addActionListener(this);
        clear.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == cencel) {
            System.exit(0);
        } else if (ae.getSource() == clear) {
            ta.setText("");

            total = 0;
            atotal = 0;
            etotal = 0;
            itotal = 0;
            ototal = 0;
            utotal = 0;
            ctotal = 0;
            tlb.setText("Total number of Vowel : " + total);
            alb.setText("Total A  : " + atotal);
            elb.setText("Total E  : " + etotal);
            ilb.setText("Total I   : " + itotal);
            olb.setText("Total O : " + ototal);
            ulb.setText("Total U : " + utotal);
            clb.setText("Total Character Count :  " + ctotal);

        }
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        char c = ke.getKeyChar();
        char r = 0;
        if (c >= 'A' && c <= 'Z') {
            r = (char) (c + 32);
        } else if (c >= 'a' && c <= 'z') {
            r = c;
        }

        if (('A' <= r && r >= 'Z')) {
            ctotal++;
            clb.setText("Total Character Count :  " + ctotal);
        }

    }

    @Override
    public void keyPressed(KeyEvent ke) {
        if (ke.VK_A == ke.getKeyCode()) {
            atotal++;
            total++;
        } else if (ke.VK_E == ke.getKeyCode()) {
            etotal++;
            total++;
        } else if (ke.VK_I == ke.getKeyCode()) {
            itotal++;
            total++;
        } else if (ke.VK_O == ke.getKeyCode()) {
            ototal++;
            total++;
        } else if (ke.VK_U == ke.getKeyCode()) {
            utotal++;
            total++;
        }

        tlb.setText("Total number of Vowel : " + total);
        alb.setText("Total A  : " + atotal);
        elb.setText("Total E  : " + etotal);
        ilb.setText("Total I   : " + itotal);
        olb.setText("Total O : " + ototal);
        ulb.setText("Total U : " + utotal);
    }

    @Override
    public void keyReleased(KeyEvent ke) {

    }

    public static void main(String[] args) {
        KeyListenerDemo frm = new KeyListenerDemo();
        frm.setVisible(true);
    }

}

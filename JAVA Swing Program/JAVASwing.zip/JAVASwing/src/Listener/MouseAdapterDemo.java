package Listener;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class MouseAdapterDemo extends JFrame {
    protected Container c;
    protected JButton btn;
    protected Font f = new Font("Times New Roman", Font.BOLD, 22);
    protected JTextArea ta;
    MouseAdapterDemo() {
        this.setBounds(20, 29, 600, 600);
        this.setTitle("This is  Mouse Adapter");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        btn = new JButton("Mouse Adapter");
        btn.setBounds(30, 140, 200, 60);
        btn.setFont(f);
        c.add(btn);
        ta = new JTextArea();
        ta.setBounds(240, 80, 300, 200);
        ta.setFont(f);
        c.add(ta);
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ta.append("Mouse Adapter\n");
            }
        });
    }

    public static void main(String[] args) {
        MouseAdapterDemo frm = new MouseAdapterDemo();
        frm.setVisible(true);
    }
}

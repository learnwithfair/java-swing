package JPanel;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class NewClass extends JFrame {
    Container c;
    JButton btn1, btn2, btn3, btn4;
    JPanel pnl1, pnl2;
    Font f = new Font("arial", Font.BOLD, 24);
    JLabel lb1, lb2;
    NewClass() {
        this.setBounds(20, 29, 700, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("This is JPanel");
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);
        lb1 = new JLabel();
        lb1.setText("Panel-1");
        lb1.setFont(f);
        lb1.setBounds(120, 40, 130, 50);
        lb1.setForeground(Color.RED);
        c.add(lb1);
        lb2 = new JLabel();
        lb2.setText("Panel-2");
        lb2.setFont(f);
        lb2.setBounds(430, 40, 130, 50);
        lb2.setForeground(Color.RED);
        c.add(lb2);
        lb2 = new JLabel();
        btn1 = new JButton("Yes");
        btn2 = new JButton("No");
        btn3 = new JButton("Submit");
        btn4 = new JButton("Cencel");
        btn1.setFont(f);
        btn2.setFont(f);
        btn3.setFont(f);
        btn4.setFont(f);
        pnl1 = new JPanel();
        pnl1.setBounds(10, 80, 300, 300);
        pnl1.setBackground(Color.BLUE);
        pnl1.add(btn1);
        pnl1.add(btn2);
        c.add(pnl1);
        pnl2 = new JPanel();
        pnl2.setBounds(320, 80, 300, 300);
        pnl2.setBackground(Color.green);
        pnl2.add(btn3);
        pnl2.add(btn4);
        c.add(pnl2);
    }
    public static void main(String[] args) {
        NewClass frm = new NewClass();
        frm.setVisible(true);
    }
}

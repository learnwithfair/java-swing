package JLabel;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class NewClass extends JFrame {
    private Container c;
    private JLabel jl;

    NewClass() {
        this.setTitle("This is JLabel");
        this.setBounds(20, 30, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        containers();
        jlabel();
    }
    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.red);
    }
    public void jlabel()
    {
        jl = new JLabel();
        jl.setText("This is Md Rahatul Islam");
        jl.setBounds(30, 30, 200, 50);
        c.add(jl);
    }

    public static void main(String[] args) {
        NewClass frame = new NewClass();
        frame.setVisible(true);
    }
}

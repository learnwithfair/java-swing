package JRadioButton;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

public class JRadioButtonDemo extends JFrame {

    private Container c;
    private JRadioButton male, female, other;
    private Font f;
    private ButtonGroup grp;
    private JLabel jl;

    JRadioButtonDemo() {
        this.setTitle("This is RadioButton Demo");
        this.setBounds(40, 40, 600, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        containers();
        radiobutton();
    }

    private void containers() {
        c = this.getContentPane();
        c.setBackground(Color.GREEN);
        c.setLayout(null);

    }

    private void radiobutton() {
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        grp = new ButtonGroup();
        jl = new JLabel();

        jl.setText("Please Select anyone Gender :  ");
        jl.setBounds(30, 5, 350, 40);
        jl.setFont(f);
        jl.setForeground(Color.BLUE);
        c.add(jl);

        male = new JRadioButton("Male");
        male.setFont(f);
        male.setBounds(20, 40, 90, 50);
        male.setBackground(Color.green);
        c.add(male);
        grp.add(male);

        female = new JRadioButton("Female");
        female.setFont(f);
        female.setBounds(120, 40, 110, 50);
        female.setSelected(true);
        female.setBackground(Color.green);
        c.add(female);

        other = new JRadioButton("Other");
        other.setFont(f);
        other.setBounds(240, 40, 90, 50);
        other.setBackground(Color.green);
        c.add(other);

        grp.add(female);
        grp.add(other);

    }

    public static void main(String[] args) {
        JRadioButtonDemo frm = new JRadioButtonDemo();
        frm.setVisible(true);
    }
}

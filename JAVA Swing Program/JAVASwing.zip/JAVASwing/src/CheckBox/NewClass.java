package CheckBox;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class NewClass extends JFrame {
    private Container c;
    private Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JCheckBox cb1, cb2, cb3, cb4, cb5;
    NewClass() {
        this.setBounds(20, 25, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("This is CheckBox");
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.MAGENTA);
        cb1 = new JCheckBox("C");
        cb1.setBounds(20, 27, 50, 60);
        cb1.setFont(f);
        cb1.setBackground(Color.MAGENTA);
        c.add(cb1);
        cb2 = new JCheckBox("C++");
        cb2.setBounds(20, 70, 70, 60);
        cb2.setFont(f);
        cb2.setBackground(Color.MAGENTA);
        c.add(cb2);
        cb3 = new JCheckBox("Java");
        cb3.setBounds(20, 110, 80, 60);
        cb3.setFont(f);
        cb3.setBackground(Color.MAGENTA);
        c.add(cb3);
        cb4 = new JCheckBox("Java Swing",true);
        cb4.setBounds(20, 150, 160, 60);
        cb4.setFont(f);
        cb4.setBackground(Color.MAGENTA);
        c.add(cb4);
        cb5 = new JCheckBox("Python");
        cb5.setBounds(20, 190, 110, 60);
        cb5.setFont(f);
        cb5.setBackground(Color.MAGENTA);
        c.add(cb5);
    }
    public static void main(String[] args) {
        NewClass frm = new NewClass();
        frm.setVisible(true);
    }
}

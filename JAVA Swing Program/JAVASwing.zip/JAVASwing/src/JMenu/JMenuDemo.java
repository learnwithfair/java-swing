package JMenu;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;

public class JMenuDemo extends JFrame implements ActionListener {

    private Container c, c2;
    private static int count = -1;
    private JTextArea ta, ta1;
    private JFileChooser fc = new JFileChooser();
    private GridLayout gl = new GridLayout();
    private GridBagLayout gbl = new GridBagLayout();
    private FlowLayout fl = new FlowLayout(FlowLayout.CENTER);

    private JTabbedPane tp = new JTabbedPane();
    private Font f, f2,f3;
    private JLabel lb, lb2, lb3, lb4, lb5, imglb;
    private JMenuBar mb;
    private JMenu file, edit, help, help2;
    private JMenuItem newm, openm, exitm, cutm, copym, svm, svasm,
            dltm, selectam, helpm, helpm2, helpm3, btnm, pstm, prntm, findm;
    JCheckBox btn = new JCheckBox("Raju");

    JMenuDemo() {
        this.setBounds(20, 29, 950, 635);
        this.setTitle("Notpad~R");
        //this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        c = this.getContentPane();
        c.setLayout(gl);
        c.setBackground(Color.magenta);
        f = new Font("Times New Roman", Font.BOLD, 16);
        f2 = new Font("Times New Roman", Font.BOLD, 24);
        f3 = new Font("Times New Roman", Font.BOLD, 44);

        btn.setSize(60, 50);
        btn.setFont(f);

        mb = new JMenuBar();
        mb.setBackground(Color.LIGHT_GRAY);
        this.setJMenuBar(mb);

        newm = new JMenuItem("New");
        newm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        newm.setFont(f);
        openm = new JMenuItem("Open");
        openm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        openm.setFont(f);
        svm = new JMenuItem("Save");
        svm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        svm.setFont(f);
        svasm = new JMenuItem("Save As...");
        svasm.setFont(f);
        exitm = new JMenuItem("Exit");
        exitm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
        exitm.setFont(f);
        cutm = new JMenuItem("Cut");
        cutm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
        cutm.setFont(f);
        copym = new JMenuItem("Copy");
        copym.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
        copym.setFont(f);
        pstm = new JMenuItem("Paste");
        pstm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
        pstm.setFont(f);
        findm = new JMenuItem("Find");
        findm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.CTRL_MASK));
        findm.setFont(f);
        dltm = new JMenuItem("Delete");

        dltm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));
        dltm.setFont(f);
        prntm = new JMenuItem("Print");
        prntm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        prntm.setFont(f);
        selectam = new JMenuItem("Select All");
        selectam.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
        selectam.setFont(f);
        helpm = new JMenuItem("Java Swing");
        helpm.setFont(f);
        helpm2 = new JMenuItem("Intriduce it's self");
        helpm2.setFont(f);
        helpm3 = new JMenuItem("Help Content");
        helpm3.setFont(f);
        //btnm = new JMenuItem( btn);

        file = new JMenu("File");
        file.setFont(f);
        file.add(btn);
        file.addSeparator();
        file.add(newm);
        file.addSeparator();
        file.add(openm);
        file.addSeparator();
        file.add(svm);
        file.addSeparator();
        file.add(svasm);
        file.addSeparator();
        file.add(prntm);
        file.addSeparator();
        file.add(exitm);
        file.addSeparator();
        mb.add(file);

        edit = new JMenu("Edit");
        edit.setFont(f);
        edit.add(cutm);
        edit.addSeparator();
        edit.add(copym);
        edit.addSeparator();
        edit.add(pstm);
        edit.addSeparator();
        edit.add(findm);
        edit.addSeparator();
        edit.add(dltm);
        edit.addSeparator();
        edit.add(selectam);
        edit.addSeparator();
        mb.add(edit);

        help = new JMenu("Help");
        help.setFont(f);
        help2 = new JMenu("About");
        help2.setFont(f);
        help2.add(helpm);
        help2.addSeparator();
        help2.add(helpm2);
        help2.addSeparator();
        help2.add(helpm3);

        help2.addSeparator();
        help.add(help2);
        mb.add(help);

        taf();

        newm.addActionListener(this);
        exitm.addActionListener(this);
        copym.addActionListener(this);
        cutm.addActionListener(this);
        dltm.addActionListener(this);
        selectam.addActionListener(this);
        pstm.addActionListener(this);
        findm.addActionListener(this);
        openm.addActionListener(this);
        svm.addActionListener(this);
        svasm.addActionListener(this);
        prntm.addActionListener(this);
        helpm2.addActionListener(this);

    }

    void taf() {
        count++;
        ta = new JTextArea();
        ta.setFont(f2);
        ta.setLayout(gl);

        ta.setSelectedTextColor(Color.RED);
        ta.setSelectionColor(Color.BLUE);
        ta.setBackground(Color.CYAN);
        JScrollPane scroll = new JScrollPane(ta, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        //ta.setBounds(0, 0, 1350, 675);
        JPanel[] pnl = new JPanel[count + 1];
        pnl[count] = new JPanel();
        pnl[count].setLayout(gl);
        pnl[count].setBackground(Color.WHITE);
        pnl[count].add(scroll);

        // tp.setBounds(5, 4, 1350, 675);
        //tp.setLayout(gl);
        if (count > 0) {
            tp.addTab("New Class" + count, pnl[count]);
        } else {
            tp.addTab("New Class", pnl[count]);
        }
        c.add(tp);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == newm) {

            taf();
        } else if (e.getSource() == exitm) {
            System.exit(0);
        } else if (e.getSource() == copym) {
            ta.copy();

        } else if (e.getSource() == cutm) {
            ta.cut();

        } else if (e.getSource() == dltm) {

            ta.replaceSelection("");
        } else if (e.getSource() == selectam) {
            ta.selectAll();
        } else if (e.getSource() == pstm) {
            ta.paste();
        } else if (e.getSource() == openm) {
            fc = new JFileChooser();
            // fc.setAcceptAllFileFilterUsed(true);
            // fc.setControlButtonsAreShown(true);
            fc.showOpenDialog(ta);

        } else if (e.getSource() == svm) {
            fc = new JFileChooser(ta.getText());

            //fc.setFileSelectionMode(0);
            // fc.setAcceptAllFileFilterUsed(true);
            // fc.setControlButtonsAreShown(true);
            fc.showSaveDialog(ta);

        } else if (e.getSource() == svasm) {
            fc = new JFileChooser();
            //fc.setFileSelectionMode(0);
            // fc.setAcceptAllFileFilterUsed(true);

            fc.showDialog(ta, "Save As");
        } else if (e.getSource() == prntm) {
            try {
                ta.print();
            } catch (PrinterException ex) {
                Logger.getLogger(JMenuDemo.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (e.getSource() == helpm2) {
            JFrame frm2 = new JFrame();
            frm2.setVisible(true);
            frm2.setBounds(220, 140, 500, 400);
            frm2.setTitle("Intriduce it's self");
            frm2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            c2 = frm2.getContentPane();
            c2.setLayout(fl);
            c2.setBackground(Color.LIGHT_GRAY);

            lb2 = new JLabel("                                                                                                                                                                                                        ");
            lb2.setForeground(Color.black);
            lb2.setFont(f2);
            c2.add(lb2);

            ImageIcon icon = new ImageIcon(getClass().getResource("RR.png"));
            imglb = new JLabel(icon);
            //imglb.setIcon();
            c2.add(imglb);

            lb2 = new JLabel("                                                                                                                                                                                                         ");
            lb2.setForeground(Color.black);
            lb2.setFont(f2);
            c2.add(lb2);

            lb2 = new JLabel("                                                                                                 Md Rahatul Islam                                                                                                  ");
            lb2.setForeground(Color.BLUE);
            lb2.setFont(f3);
            c2.add(lb2);

            lb2 = new JLabel("He is a Engineering student of Information and Communication Engineering (ICE) at PUST.");
            lb2.setForeground(Color.black);
            lb2.setFont(f2);
            c2.add(lb2);

            lb3 = new JLabel("                                            Gmail ID. rahatul.ice.09.pust@gmail.com                                        ");
            lb3.setForeground(Color.black);
            lb3.setFont(f2);
            c2.add(lb3);

            lb4 = new JLabel("                                                  Facebook ID.Md Rahatul Islam                                                  ");
            lb4.setForeground(Color.black);
            lb4.setFont(f2);
            c2.add(lb4);

            lb5 = new JLabel("                                                      Mobile NO.  01790-224950                                                 ");
            lb5.setForeground(Color.black);
            lb5.setFont(f2);
            c2.add(lb5);

            lb5 = new JLabel("                                                                   ® Thanks ®                                                              ");
            lb5.setForeground(Color.black);
            lb5.setFont(f2);
            c2.add(lb5);

        } else if (e.getSource() == findm) {
        }

    }

    public static void main(String[] args) {
        JMenuDemo frm = new JMenuDemo();
        frm.setVisible(true);
    }

}

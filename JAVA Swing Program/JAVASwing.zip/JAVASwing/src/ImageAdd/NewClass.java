package ImageAdd;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class NewClass extends JFrame {

    private Container c;
    private Font f;
    private ImageIcon icon1, icon2;
    private JLabel jl, tl, imgl;

    NewClass() {
        this.setTitle("This is Image Icon");
        this.setBounds(20, 30, 700, 680);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        containers();
        jlabel();
    }

    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
    }

    public void jlabel() {
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        icon1 = new ImageIcon(getClass().getResource("RRR.jpg"));
        jl = new JLabel("This is Md Rahatul Islam", icon1, JLabel.LEFT);
        jl.setFont(f);
        jl.setForeground(Color.red);
        jl.setBounds(50, 10, 500, 300);
        c.add(jl);

        icon2 = new ImageIcon(getClass().getResource("RR.png"));
        imgl = new JLabel();
        imgl.setIcon(icon2);
        imgl.setBounds(50, 330, icon2.getIconWidth(), icon2.getIconHeight());
        c.add(imgl);

        tl = new JLabel();
        tl.setText("This is Md Rahatul Islam");
        tl.setFont(f);
        tl.setForeground(Color.blue);
        tl.setBounds(300, 400, 500, 50);
        c.add(tl);
    }

    public static void main(String[] args) {
        NewClass frame = new NewClass();
        frame.setVisible(true);
    }
}

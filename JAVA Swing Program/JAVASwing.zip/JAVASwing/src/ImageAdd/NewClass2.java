package ImageAdd;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class NewClass2 extends JFrame {

    private Container c;
    private Font f;
    private ImageIcon icon2;
    private JLabel tl, imgl;

    NewClass2() {
        this.setTitle("This is Image Icon");
        this.setBounds(20, 30, 600, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        containers();
        jlabel();
    }
    
    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
    }

    public void jlabel() {
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        icon2 = new ImageIcon(getClass().getResource("RR.png"));
        imgl = new JLabel();
        imgl.setIcon(icon2);
        imgl.setBounds(50, 10, icon2.getIconWidth(), icon2.getIconHeight());
        c.add(imgl);

        tl = new JLabel();
        tl.setText("This is Md Rahatul Islam");
        tl.setFont(f);
        tl.setForeground(Color.blue);
        tl.setBounds(300, 100, 500, 50);
        c.add(tl);
    }

    public static void main(String[] args) {
        NewClass2 frame = new NewClass2();
        frame.setVisible(true);
    }
}

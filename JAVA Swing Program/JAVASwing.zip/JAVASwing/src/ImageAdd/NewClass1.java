package ImageAdd;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class NewClass1 extends JFrame {

    private Container c;
    private Font f;
    private ImageIcon icon1;
    private JLabel jl;

    NewClass1() {
        this.setTitle("This is Image Icon");
        this.setBounds(20, 30, 700, 680);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        containers();
        jlabel();
    }

    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
    }

    public void jlabel() {
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        icon1 = new ImageIcon(getClass().getResource("RRR.jpg"));
        jl = new JLabel("This is Md Rahatul Islam", icon1, JLabel.LEFT);
        jl.setFont(f);
        jl.setForeground(Color.red);
        jl.setBounds(50, 10, 500, 300);
        c.add(jl);
    }

    public static void main(String[] args) {
        NewClass1 frame = new NewClass1();
        frame.setVisible(true);
    }

}

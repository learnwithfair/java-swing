package TextArea;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class TextAreaDemo extends JFrame {

    private Container c;
    private Font f;
    private JTextArea ta;
    private JLabel jl;
    private JScrollPane scroll;

    private TextAreaDemo() {
        this.setTitle("This is Text area Demo ");
        this.setBounds(20, 30, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f = new Font("Times new Roman", Font.BOLD + Font.ITALIC, 22);
        containers();
        textarea();
    }

    private void containers() {

        c = this.getContentPane();
        c.setBackground(Color.green);
        c.setLayout(null);
    }

    private void textarea() {
        jl = new JLabel();
        jl.setText("Enter your Comments :");
        jl.setBounds(40, 40, 250, 100);
        jl.setFont(f);
        jl.setForeground(Color.blue);
        c.add(jl);
        ta = new JTextArea();
        ta.setFont(f);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setForeground(Color.blue);
        ta.setBackground(Color.PINK);
        scroll = new JScrollPane(ta, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setBounds(40, 120, 200, 250);
        c.add(scroll);
    }

    public static void main(String[] args) {
        TextAreaDemo frm = new TextAreaDemo();
        frm.setVisible(true);
    }
}

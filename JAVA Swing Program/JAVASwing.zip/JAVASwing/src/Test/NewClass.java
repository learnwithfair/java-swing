
package Test;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SpringLayout;

public class NewClass extends JFrame {
    private Container c;
    private SpringLayout slayout= new SpringLayout();
    private GridLayout glayout= new GridLayout(5,1);
    private Font f = new Font("arial",Font.BOLD,22);
    private JButton btn1,btn2,btn3,btn4,btn5;
    NewClass()
    {
        this.setTitle("Test");
        this.setBounds(20,30,500,600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        c = this.getContentPane();
        c.setBackground(Color.BLUE);
        c.setLayout(glayout);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
       c.add(btn1);
        c.add(btn2);
        c.add(btn3);
        c.add(btn4);
        c.add(btn5);
    }
    public static void main(String[] args) {
        NewClass frm = new NewClass();
        frm.setVisible(true);
    }
    
}


package Test;

import javax.swing.JOptionPane;

public class TestDemo {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"RRRR");
    }
}

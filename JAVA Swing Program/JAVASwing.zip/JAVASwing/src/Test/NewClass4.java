
package Test;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;


public class NewClass4 implements MouseMotionListener{

    @Override
    public void mouseDragged(MouseEvent me) {
    }

    @Override
    public void mouseMoved(MouseEvent me) {
    }
    
}

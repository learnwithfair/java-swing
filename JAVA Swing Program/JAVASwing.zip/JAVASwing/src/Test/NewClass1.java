package Test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class NewClass1 extends JFrame implements ActionListener {

    JButton btn = new JButton("Open");

    NewClass1() {
        btn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }

    public static void main(String[] args) {
        NewClass1 frm = new NewClass1();
    }

}

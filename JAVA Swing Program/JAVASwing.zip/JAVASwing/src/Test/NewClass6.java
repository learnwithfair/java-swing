package Test;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JTabbedPane;

public class NewClass6 extends JFrame {

    private Container c;

    NewClass6() {
        this.setBounds(20, 29, 500, 400);
        this.setTitle("This is ");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        JMenuItem mi = new JMenuItem("JJJJ");
        JMenuItem mi2 = new JMenuItem("NNNN");
        JMenuItem mi3 = new JMenuItem("SSS");
        
        JPopupMenu ppm = new JPopupMenu("RRR");
        JProgressBar pb = new JProgressBar();
        pb.setBackground(Color.yellow);
      
       
       
        ppm.add(mi);
        ppm.add(mi2);
        ppm.add(mi3);
        JPopupMenu ppm2 = new JPopupMenu("AAAA");
       
        ppm2.add(mi);
        ppm2.add(mi2);
        ppm2.add(mi3);
        c.add(ppm);
        ppm.setBackground(Color.yellow);
        JTabbedPane tp = new JTabbedPane();
         tp.setBounds(30,40,200,300);
         tp.setBackground(Color.yellow);
        //tp.add(ppm);
        //tp.add(ppm2);
        c.add(tp);
    }

    public static void main(String[] args) {
        NewClass6 frm = new NewClass6();
        frm.setVisible(true);
    }

}

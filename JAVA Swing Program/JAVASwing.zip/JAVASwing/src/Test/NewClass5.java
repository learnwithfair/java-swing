
package Test;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class NewClass5 implements FocusListener{

    @Override
    public void focusGained(FocusEvent fe) {
    }

    @Override
    public void focusLost(FocusEvent fe) {
    }
    
}

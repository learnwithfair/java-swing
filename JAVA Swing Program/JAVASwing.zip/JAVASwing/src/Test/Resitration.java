package Test;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

public class Resitration extends JFrame {

    protected Container c;
    protected int count = 0, r = 0, j = 0, t = -1;
    protected Font f1 = new Font("Times New Roman", Font.BOLD, 70);
    protected Font f2 = new Font("Times New Roman", Font.BOLD, 24);
    protected Font f3 = new Font("Times New Roman", Font.BOLD, 20);
    protected JTextField idtf, nametf, fathernametf, mothernametf, birthtf, meritialtf,
            presenttf, permanenttf, contacttf, emailtf, religiontf, gendertf, heightf;
    protected JLabel namelb, hiddinglb, idlb, fathernamelb, mothernamelb, birthlb, meritiallb,
            presentlb, permanentlb, contactlb, emaillb, religionlb, genderlb, bloadlb, nationalitilb, heightlb, weightlb1, weightlb2;
    protected JPanel pnl1;
    protected JComboBox cbox, bloadcbox, nationaliticbox;
    protected JScrollPane scroll;
    protected JRadioButton malebtn, femalebtn, otherbtn;
    protected ButtonGroup grp;
    protected JSpinner weightsp;
    protected JButton nextbtn;

    protected GridBagLayout gblaout = new GridBagLayout();

    Resitration() {

        this.setBounds(0, 0, 1350, 700);
        this.setTitle("Student Registration Form");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.LIGHT_GRAY);
        c.setLayout(null);

        hiddinglb = new JLabel();
        hiddinglb.setText("\"Student's Registration Form\"");
        hiddinglb.setFont(f1);
        hiddinglb.setBounds(210, 0, 940, 120);
        hiddinglb.setForeground(Color.BLUE);
        c.add(hiddinglb);
        pnl1 = new JPanel();

        pnl1.setBackground(Color.LIGHT_GRAY);
        pnl1.setLayout(null);
        pnl1.setBounds(20, 80, 1320, 700);
        idlb = new JLabel("Enter Student ID        : ");
        idlb.setBounds(0, 80, 250, 60);
        idlb.setFont(f2);
        pnl1.add(idlb);
        idtf = new JTextField();
        idtf.setBounds(250, 80, 350, 60);
        idtf.setBackground(Color.LIGHT_GRAY);
        idtf.setToolTipText("Student ID Hint's : 190609");
        idtf.setSelectionColor(Color.RED);
        idtf.setHorizontalAlignment(JTextField.CENTER);
        idtf.setFont(f2);
        pnl1.add(idtf);

        namelb = new JLabel("Enter Student Name   : ");
        namelb.setBounds(700, 80, 250, 60);
        namelb.setFont(f2);
        pnl1.add(namelb);
        nametf = new JTextField();
        nametf.setBounds(963, 80, 350, 60);
        nametf.setBackground(Color.LIGHT_GRAY);
        nametf.setToolTipText("Student Name Hint's : Md Rahatul Islam");
        nametf.setSelectionColor(Color.RED);
        nametf.setHorizontalAlignment(JTextField.CENTER);
        nametf.setFont(f2);
        pnl1.add(nametf);

        fathernamelb = new JLabel("Enter Father's Name : ");
        fathernamelb.setBounds(0, 150, 250, 60);
        fathernamelb.setFont(f2);
        pnl1.add(fathernamelb);
        fathernametf = new JTextField();
        fathernametf.setBounds(250, 150, 350, 60);
        fathernametf.setBackground(Color.LIGHT_GRAY);
        fathernametf.setToolTipText("Faher's Name Hint's : Mohammad Ali");
        fathernametf.setSelectionColor(Color.RED);
        fathernametf.setHorizontalAlignment(JTextField.CENTER);
        fathernametf.setFont(f2);
        pnl1.add(fathernametf);

        mothernamelb = new JLabel("Enter Mother's Name : ");
        mothernamelb.setBounds(700, 150, 250, 60);
        mothernamelb.setFont(f2);
        pnl1.add(mothernamelb);
        mothernametf = new JTextField();
        mothernametf.setBounds(963, 150, 350, 60);
        mothernametf.setBackground(Color.LIGHT_GRAY);
        mothernametf.setToolTipText("Moher's Name Hint's : Most. Sultana Raziya");
        mothernametf.setSelectionColor(Color.RED);
        mothernametf.setHorizontalAlignment(JTextField.CENTER);
        mothernametf.setFont(f2);
        pnl1.add(mothernametf);

        birthlb = new JLabel("Enter Date of Birth    : ");
        birthlb.setBounds(0, 220, 250, 60);
        birthlb.setFont(f2);
        pnl1.add(birthlb);
        birthtf = new JTextField();
        birthtf.setBounds(250, 220, 350, 60);
        birthtf.setBackground(Color.LIGHT_GRAY);
        birthtf.setToolTipText("Date of Birth Hint's : 03-03-1999");
        birthtf.setSelectionColor(Color.RED);
        birthtf.setHorizontalAlignment(JTextField.CENTER);
        birthtf.setFont(f2);
        pnl1.add(birthtf);

        meritiallb = new JLabel("Select Marital Status  : ");
        meritiallb.setBounds(700, 220, 250, 60);
        meritiallb.setFont(f2);
        pnl1.add(meritiallb);
        cbox = new JComboBox();
        cbox.setBounds(963, 220, 350, 60);
        cbox.setBackground(Color.LIGHT_GRAY);
        cbox.addItem("                     Married");
        cbox.addItem("                     Unmarried");
        cbox.setSelectedIndex(0);
        cbox.setToolTipText("Marital Status Hint's : Married / Unmarried");
        cbox.setEditable(false);
        cbox.setFont(f2);
        pnl1.add(cbox);

        genderlb = new JLabel("Select any Gender      : ");
        genderlb.setBounds(0, 290, 250, 60);

        genderlb.setFont(f2);
        pnl1.add(genderlb);
        malebtn = new JRadioButton("Male");
        malebtn.setBackground(Color.LIGHT_GRAY);
        malebtn.setFont(f2);
        malebtn.setBounds(250, 290, 90, 60);
        pnl1.add(malebtn);
        femalebtn = new JRadioButton("Female");
        femalebtn.setBackground(Color.LIGHT_GRAY);
        femalebtn.setFont(f2);
        femalebtn.setBounds(380, 290, 120, 60);
        pnl1.add(femalebtn);
        otherbtn = new JRadioButton("Other", true);
        otherbtn.setBounds(520, 290, 90, 60);
        otherbtn.setBackground(Color.LIGHT_GRAY);
        otherbtn.setFont(f2);
        pnl1.add(otherbtn);
        grp = new ButtonGroup();
        grp.add(malebtn);
        grp.add(femalebtn);
        grp.add(otherbtn);

        religionlb = new JLabel("Enter Student Religion       :");
        religionlb.setBounds(700, 290, 250, 60);
        religionlb.setFont(f3);
        pnl1.add(religionlb);
        religiontf = new JTextField();
        religiontf.setBounds(963, 290, 350, 60);
        religiontf.setBackground(Color.LIGHT_GRAY);
        religiontf.setHorizontalAlignment(JTextField.CENTER);
        religiontf.setToolTipText("Religion Hint's : Islam,Hindu");
        religiontf.setFont(f2);
        pnl1.add(religiontf);

        contactlb = new JLabel("Student Mobile Number     : ");
        contactlb.setBounds(0, 360, 250, 60);
        contactlb.setFont(f3);
        pnl1.add(contactlb);
        contacttf = new JTextField("            +088");
        contacttf.setBounds(250, 360, 350, 60);
        contacttf.setBackground(Color.LIGHT_GRAY);
        contacttf.setToolTipText("Mobile Number Hint's : 01790224950");
        contacttf.setSelectionColor(Color.RED);
        contacttf.setFont(f3);
        pnl1.add(contacttf);
        contacttf.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent ke) {
            }

            @Override
            public void keyPressed(KeyEvent ke) {
                if (ke.getKeyCode() >= 48 && ke.getKeyCode() <= 57) {
                    count++;
                    r = 0;
                } else if (ke.getKeyCode() == 8 || ke.getKeyCode() == 127) {

                    if (count > 0) {
                        count--;

                    }
                    r = 0;
                } else {
                    r++;
                    JOptionPane.showMessageDialog(contacttf, "This Phone Number is Invalid Please Try Again.");
                    StringBuilder str = new StringBuilder();
                    str.append(contacttf.getText());
                    char ca = ke.getKeyChar();
                    String s = String.valueOf(ca);
                    int f = str.lastIndexOf(s);
                    String value = str.deleteCharAt(f).toString();
                    contacttf.setText(value);
                }
                if (r == 0 && count > 11) {
                    r = 0;
                    count--;
                    JOptionPane.showMessageDialog(contacttf, "This Phone Number Length is Invalid Please Try Again.");
                    StringBuilder str2 = new StringBuilder();
                    str2.append(contacttf.getText());
                    char ca2 = ke.getKeyChar();
                    String s2 = String.valueOf(ca2);
                    int f2 = str2.lastIndexOf(s2);
                    String value2 = str2.deleteCharAt(f2).toString();
                    contacttf.setText(value2);

                }

            }

            @Override
            public void keyReleased(KeyEvent ke) {
                String str = contacttf.getText();
                String str2 = "            +088" + ke.getKeyChar();
                if (str.isEmpty()) {
                    count = 0;
                    r = 0;
                    contacttf.setText("            +088");
                }
                if (str2.equals(str)) {
                    count = 1;
                    r = 0;
                    contacttf.setText(str2);
                }
            }

        });
        contacttf.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe) {
            }

            @Override
            public void focusLost(FocusEvent fe) {
                if (r == 0) {

                    if (count > 0 && count < 11) {
                        JOptionPane.showMessageDialog(contacttf, "This Phone Number Length is Invalid Please Try Again.");
                    }
                }

            }

        });

        emaillb = new JLabel("Enter Student Email ID      : ");
        emaillb.setBounds(700, 360, 250, 60);
        emaillb.setFont(f3);
        pnl1.add(emaillb);
        emailtf = new JTextField("Ex-rahatul.ice.09.pust@gmail.com");
        emailtf.setBounds(963, 360, 350, 60);
        emailtf.setBackground(Color.LIGHT_GRAY);
        emailtf.setHorizontalAlignment(JTextField.CENTER);
        emailtf.setToolTipText("Email ID Hint's : rahatul.ice.09.pust@gmail.com");
        emailtf.setFont(f3);
        pnl1.add(emailtf);

        emailtf.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                String str = emailtf.getText();
                if (j == 0) {
                    emailtf.setText("");
                    j++;

                }

            }

            @Override
            public void keyPressed(KeyEvent ke) {
            }

            @Override
            public void keyReleased(KeyEvent ke) {
            }

        });
        presentlb = new JLabel("Enter Present Address       : ");
        presentlb.setBounds(0, 430, 250, 60);
        presentlb.setFont(f3);
        pnl1.add(presentlb);
        presenttf = new JTextField();
        presenttf.setBounds(250, 430, 350, 60);
        presenttf.setBackground(Color.LIGHT_GRAY);
        presenttf.setToolTipText("Present Address Hint's : Loskarpur,Pabna,Rajshahi");
        presenttf.setSelectionColor(Color.RED);
        presenttf.setHorizontalAlignment(JTextField.CENTER);
        presenttf.setFont(f3);
        pnl1.add(presenttf);

        permanentlb = new JLabel("Enter Permanent Address  : ");
        permanentlb.setBounds(700, 430, 250, 60);
        permanentlb.setFont(f3);
        pnl1.add(permanentlb);
        permanenttf = new JTextField();
        permanenttf.setBounds(963, 430, 350, 60);
        permanenttf.setBackground(Color.LIGHT_GRAY);
        permanenttf.setHorizontalAlignment(JTextField.CENTER);
        permanenttf.setToolTipText(" Permanent Address Hint's : Hatibandha, Lalmonirhat,Rangpur");
        permanenttf.setFont(f3);
        pnl1.add(permanenttf);

        heightlb = new JLabel("Enter Student Height : ");
        heightlb.setBounds(0, 500, 250, 60);
        heightlb.setFont(f2);
        pnl1.add(heightlb);
        heightf = new JTextField();
        heightf.setBounds(250, 500, 350, 60);
        heightf.setBackground(Color.LIGHT_GRAY);
        heightf.setToolTipText("Student Height Hint's : 5.9''");
        heightf.setSelectionColor(Color.RED);
        heightf.setHorizontalAlignment(JTextField.CENTER);
        heightf.setFont(f2);
        pnl1.add(heightf);

        weightlb1 = new JLabel("Select Student Weight : ");
        weightlb1.setBounds(700, 500, 250, 60);
        weightlb1.setFont(f2);
        pnl1.add(weightlb1);
        SpinnerNumberModel model = new SpinnerNumberModel(40, 20, 90, 1);
        weightsp = new JSpinner(model);
        weightsp.setFont(f1);
        weightsp.setBackground(Color.LIGHT_GRAY);
        weightsp.setBounds(963, 500, 200, 60);
        pnl1.add(weightsp);
        weightlb2 = new JLabel("Kg");
        weightlb2.setBounds(1190, 500, 150, 75);
        weightlb2.setFont(f1);
        pnl1.add(weightlb2);

        bloadlb = new JLabel("Selecte your Bload Group :");
        bloadlb.setBounds(0, 570, 250, 50);
        bloadlb.setFont(f3);
        pnl1.add(bloadlb);
        String[] str = {"                    A+", "                    A-", "                    B+",
            "                    B-", "                    AB+", "                    AB-", "                    O+", "                    O-"};
        bloadcbox = new JComboBox(str);
        bloadcbox.setBounds(250, 570, 350, 50);
        bloadcbox.setSelectedIndex(4);
        bloadcbox.setBackground(Color.LIGHT_GRAY);
        bloadcbox.setFont(f2);
        pnl1.add(bloadcbox);

        nationalitilb = new JLabel("Enter Student Nationality   :");
        nationalitilb.setBounds(700, 570, 250, 50);
        nationalitilb.setFont(f3);
        pnl1.add(nationalitilb);
        String[] countryname = {"    America", "    Argentina", "    Bhutan", "    Bangladesh",
            "    Brazil", "    Canada", "    England", "    Japan", "    India", "    Pakistan", "    Rasia", "    London"};
        nationaliticbox = new JComboBox(countryname);
        nationaliticbox.setBounds(963, 570, 200, 50);
        nationaliticbox.setBackground(Color.LIGHT_GRAY);
        nationaliticbox.setSelectedIndex(3);
        nationaliticbox.setEditable(true);
        nationaliticbox.setFont(f2);
        pnl1.add(nationaliticbox);

        nextbtn = new JButton("Next");
        nextbtn.setBounds(1220, 580, 90, 40);
        nextbtn.setFont(f2);
        nextbtn.setForeground(Color.RED);
        nextbtn.setBackground(Color.LIGHT_GRAY);
        pnl1.add(nextbtn);
        c.add(pnl1);

    }

    public static void main(String[] args) {
        Resitration frm = new Resitration();
        frm.setVisible(true);
    }

}

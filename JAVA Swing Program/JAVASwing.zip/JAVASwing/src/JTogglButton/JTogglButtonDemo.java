package JTogglButton;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JToggleButton;

public class JTogglButtonDemo extends JFrame {
    private Container c;
    private Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JToggleButton tb1, tb2;
    JTogglButtonDemo() {
        this.setTitle("This is JToggleButton");
        this.setBounds(20, 29, 500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        c.setLayout(null);
        tb1 = new JToggleButton("Selected");
        tb1.setBounds(50, 40, 150, 50);
        tb1.setFont(f);
        c.add(tb1);
        tb1.setForeground(Color.RED);
        tb2 = new JToggleButton("Unselected");
        tb2.setBounds(220, 40, 170, 50);
        tb2.setFont(f);
        tb2.setForeground(Color.BLUE);
        c.add(tb2);
    }
    public static void main(String[] args) {
        JTogglButtonDemo frm = new JTogglButtonDemo();
        frm.setVisible(true);
    }
}

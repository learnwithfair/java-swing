package MultiplicationTable;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Test extends JFrame {

    private Container c;
    private JLabel jl, imgl;
    private JTextField tf;
    private JTextArea ta;
    private JButton btn;
    private Font f;
    private ImageIcon icon, icon2;
    private GridLayout glayout, playout;
    private BoxLayout boxlayout;
    private JButton btn2, btn3, btn4, btn5, btn1;
    private JPanel panel1, panel2, panel3, panel4;

    Test() {
        this.setTitle("Multiplication Table : ");
        this.setBounds(400, 0, 650, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f = new Font("Times new Roman", Font.BOLD + Font.ITALIC, 22);
        glayout = new GridLayout(4, 1);

        containers();

    }

    private void containers() {
        c = this.getContentPane();
        c.setBackground(Color.blue);
        c.setLayout(glayout);

        icon = new ImageIcon(getClass().getResource("R.png"));
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel4 = new JPanel();
        panel1.setBackground(Color.RED);
        panel2.setBackground(Color.RED);
        panel3.setBackground(Color.magenta);
        c.add(panel1);
        imgl = new JLabel();
        imgl.setIcon(icon);
        panel1.add(imgl);
        icon2 = new ImageIcon(getClass().getResource("R2.png"));
        imgl = new JLabel();
        imgl.setIcon(icon2);
        panel2.add(imgl);
        c.add(panel2);

        boxlayout = new BoxLayout(panel3,BoxLayout.X_AXIS);
        jl = new JLabel();
        jl.setText("Enter any number : ");
        jl.setFont(f);
       // jl.setBounds(20,30,200,60);
        jl.setForeground(Color.blue);
        jl.setOpaque(true);
        jl.setBackground(Color.PINK);
       
        tf = new JTextField();
        tf.setFont(f);
        tf.setHorizontalAlignment(JTextField.CENTER);
       tf.setSize(200, 200);
       c.add(panel3);
     // panel3.add(panel3);
        panel3.add(tf);
         
        

        ta = new JTextArea("RRRR");
        ta.setBackground(Color.ORANGE);
        JScrollPane scroll = new JScrollPane(ta,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        btn1 = new JButton("1");
       btn2 = new JButton("2");
        btn3= new JButton("3");
         btn4 = new JButton("4");

        panel4.add(scroll);
        panel4.add(btn1);
        panel4.add(btn2);
        panel4.add(btn3);
        panel4.add(btn4);
        c.add(panel4);
    }

    public static void main(String[] args) {
        Test frm = new Test();
        frm.setVisible(true);
    }
}

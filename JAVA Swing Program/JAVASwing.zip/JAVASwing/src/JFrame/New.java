package JFrame;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class New extends JFrame {
    private ImageIcon icon;
    New() {
        initcomponents();
    }

    public void initcomponents() {
        icon = new ImageIcon(getClass().getResource("RR.png"));
        this.setIconImage(icon.getImage());
    }
    public static void main(String[] args) {
        New frame = new New();
        frame.setVisible(true);
        frame.setTitle("This is JFrame ");
        frame.setSize(700, 500);
        frame.setLocation(20, 30);
        frame.setLocationRelativeTo(null);
        frame.setResizable(true);
        // frame.setBounds(20, 30, 700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

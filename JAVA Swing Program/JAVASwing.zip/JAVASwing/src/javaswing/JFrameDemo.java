package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class JFrameDemo extends JFrame {

    private Container c;
    private ImageIcon icon;
    private JLabel label, pfl, tfl;
    private Font f;
    private JTextField tf;
    private JPasswordField pf;

    JFrameDemo() {
        c = this.getContentPane();
        c.setBackground(Color.blue);
        this.setTitle("This is JFrame :");
        this.setLayout(null);
        // this.setBounds(20,20,400,500);
        icon = new ImageIcon(getClass().getResource("RR.png"));
        this.setIconImage(icon.getImage());
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        // this.setSize(400, 600);
        //  this.setResizable(false);
        //this.setLocationRelativeTo(null);
        this.setBounds(30, 30, 700, 550);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initcomponent();
    }

    public void initcomponent() {
        label = new JLabel("This is MD Rahatul Islam", icon, JLabel.LEFT);

        label.setFont(f);
        label.setBounds(40, 10, 500, 300);
        label.setOpaque(true);
        label.setBackground(Color.BLUE);
        label.setForeground(Color.red);
        c.add(label);

        tfl = new JLabel();
        tfl.setForeground(Color.green);
        tfl.setText("Enter Number :");
        tfl.setBounds(40, 320, 200, 60);
        tfl.setFont(f);
        c.add(tfl);

        tf = new JTextField();

        tf.setToolTipText("Hint's : Rahatul Islam");
        tf.setBounds(250, 330, 120, 40);
        tf.setFont(f);
        tf.setBackground(Color.yellow);
        tf.setForeground(Color.LIGHT_GRAY);
        tf.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf);

        pf = new JPasswordField();
        pfl = new JLabel();
        pfl.setText("Enter Password :");
        pfl.setBounds(40, 390, 200, 60);
        pfl.setFont(f);
        c.add(pfl);

        pf.setToolTipText("Pasword Hint :123456789");
        pf.setBounds(250, 400, 120, 40);
        pf.setFont(f);
        pf.setBackground(Color.yellow);
        pf.setForeground(Color.BLACK);
        pf.setHorizontalAlignment(JTextField.CENTER);
        c.add(pf);

    }

    public static void main(String[] args) {
        JFrameDemo frame = new JFrameDemo();
        frame.setVisible(true);
    }
}

package javaswing;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Dialog {

    private ImageIcon icon;

    Dialog() {
        icon = new ImageIcon(getClass().getResource("RR.png"));
        String name = JOptionPane.showInputDialog(null, "Enter Your Name : ");
        JOptionPane.showMessageDialog(null, name + " Welcome to JAVA Swing.", "Welcome Message", JOptionPane.INFORMATION_MESSAGE, icon);
        int number;
        do {
            number = JOptionPane.showConfirmDialog(null, "Are you exit ?", "Confirm Message", JOptionPane.YES_NO_OPTION);
            if (number == JOptionPane.YES_OPTION) {
                System.exit(0);
            } else if (number == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, name + " Welcome to JAVA Swing.", "Welcome Message", JOptionPane.INFORMATION_MESSAGE, icon);
            }
        } while (number == JOptionPane.NO_OPTION);
    }

    public static void main(String[] args) {

        Dialog ob = new Dialog();
    }
}

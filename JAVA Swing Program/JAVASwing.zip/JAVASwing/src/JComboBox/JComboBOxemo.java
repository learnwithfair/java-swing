package JComboBox;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JFrame;

public class JComboBOxemo extends JFrame {
    private Container c;
    private Font f = new Font("arial", Font.ITALIC + Font.BOLD, 24);
    private JComboBox cb1;
    String[] str ={"C","C++"};
    JComboBOxemo() {
        this.setTitle("This is JComboBox");
        this.setBounds(20, 29, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.BLUE);
        cb1 = new JComboBox(str);
        cb1.setBounds(20, 40, 170, 50);
        cb1.setFont(f);
        cb1.setEditable(true);
        cb1.addItem("Java");
        cb1.addItem("Java Swing");
        cb1.addItem("Phython");
        cb1.setSelectedIndex(3);
        c.add(cb1);
    }
    public static void main(String[] args) {
        JComboBOxemo frm = new JComboBOxemo();
        frm.setVisible(true);
    }
}

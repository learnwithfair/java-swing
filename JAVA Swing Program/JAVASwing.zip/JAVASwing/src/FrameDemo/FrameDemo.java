package FrameDemo;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;

public class FrameDemo extends JFrame {

    protected Container c;

    FrameDemo() {
        this.setBounds(20, 29, 500, 400);
        this.setTitle("This is ");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);

    }

    public static void main(String[] args) {
        FrameDemo frm = new FrameDemo();
        frm.setVisible(true);
    }

}

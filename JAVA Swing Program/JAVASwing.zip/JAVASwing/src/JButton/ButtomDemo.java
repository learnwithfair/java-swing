package JButton;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class ButtomDemo extends JFrame {

    private Container c;
    private Font f;
    private JButton btn, cbtn;
    private Cursor cursor;
    private JLabel jl, pl;
    private JTextField tf;
    private JPasswordField pf;

    ButtomDemo() {
        this.setTitle("This is Buttom Demo");
        this.setBounds(20, 30, 500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        cursor = new Cursor(Cursor.HAND_CURSOR);
        containers();
        jlabel();
        button();
    }

    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.GREEN);
    }

    public void jlabel() {
        jl = new JLabel();
        jl.setText("Enter your Name : ");
        jl.setBounds(10, 20, 200, 50);
        jl.setFont(f);
        jl.setForeground(Color.blue);
        c.add(jl);

        tf = new JTextField();
        tf.setBounds(210, 20, 200, 50);
        tf.setFont(f);
        tf.setToolTipText("Hint's Rahatul Islam");
        tf.setHorizontalAlignment(JTextField.CENTER);
        tf.setBackground(Color.pink);
        c.add(tf);

        pl = new JLabel();
        pl.setText("Enter Password : ");
        pl.setBounds(10, 80, 200, 50);
        pl.setFont(f);
        pl.setForeground(Color.blue);
        c.add(pl);

        pf = new JPasswordField();
        pf.setBounds(210, 80, 200, 50);
        pf.setFont(f);
        pf.setToolTipText("Password Hint's 123456789");
        pf.setHorizontalAlignment(JTextField.CENTER);
        pf.setBackground(Color.pink);
        c.add(pf);
    }

    public void button() {
        btn = new JButton();
        btn.setFont(f);
        btn.setText("Cencel");
        btn.setCursor(cursor);
        btn.setBounds(190, 200, 110, 50);
        btn.setForeground(Color.red);
        c.add(btn);

        cbtn = new JButton();
        cbtn.setFont(f);
        cbtn.setText("Submit");
        cbtn.setCursor(cursor);
        cbtn.setBounds(310, 200, 110, 50);
        cbtn.setForeground(Color.red);
        c.add(cbtn);
    }

    public static void main(String[] args) {
        ButtomDemo frm = new ButtomDemo();
        frm.setVisible(true);
    }
}

package Layout;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class GridBagLayoutDemo extends JFrame {

    Container c;
    Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JButton btn1, btn2, btn3, btn4;

    GridBagLayoutDemo() {
        this.setTitle("This is GridBagLayout");
        this.setBounds(20, 29, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.BLUE);
        GridBagLayout gblayout = new GridBagLayout();
        c.setLayout(gblayout);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn1.setFont(f);
        btn2.setFont(f);
        btn3.setFont(f);
        btn4.setFont(f);
        c.add(btn1);
        c.add(btn2);
        c.add(btn3);
        c.add(btn4);
    }

    public static void main(String[] args) {
        GridBagLayoutDemo frm = new GridBagLayoutDemo();
        frm.setVisible(true);
    }
}

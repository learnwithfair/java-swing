package Layout;

import java.awt.CardLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class CarLayoutDemo extends JFrame implements ActionListener {
    private Container c;
    private Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JButton btn1, btn2, btn3, btn4;
    private CardLayout clayout;
    CarLayoutDemo() {
        this.setTitle("This is CardLayout");
        this.setBounds(20, 29, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        clayout = new CardLayout(10, 15);
        c.setLayout(clayout);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn1.setFont(f);
        btn2.setFont(f);
        btn3.setFont(f);
        btn4.setFont(f);
        c.add(btn1, "First");
        c.add(btn2, "Second");
        c.add(btn3, "Third");
        c.add(btn4, "Fourth");
        clayout.show(c, "Third");
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        clayout.next(c);
        // clayout.previous(c);
        // clayout.first(c);
        //clayout.last(c);
    }
    public static void main(String[] args) {
        CarLayoutDemo frm = new CarLayoutDemo();
        frm.setVisible(true);
    }
}

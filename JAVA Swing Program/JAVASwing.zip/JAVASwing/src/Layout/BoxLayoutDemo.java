package Layout;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class BoxLayoutDemo extends JFrame {
    private Container c;
    private Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JButton btn1, btn2, btn3, btn4, btn5;
    private BoxLayout blayout;
    BoxLayoutDemo() {
        this.setTitle("This is BoxLayout");
        this.setBounds(20, 29, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.magenta);
        blayout = new BoxLayout(c, BoxLayout.Y_AXIS);
        c.setLayout(blayout);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        btn1.setFont(f);
        btn2.setFont(f);
        btn3.setFont(f);
        btn4.setFont(f);
        btn5.setFont(f);
        c.add(btn1);
        c.add(Box.createVerticalStrut(10));
        //c.add(Box.createHorizontalStrut(10));
        c.add(btn2);
        c.add(Box.createVerticalStrut(10));
        c.add(btn3);
        c.add(Box.createVerticalStrut(10));
        c.add(btn4);
        c.add(Box.createVerticalStrut(10));
        c.add(btn5);
        c.add(Box.createVerticalStrut(10));
    }
    public static void main(String[] args) {
        BoxLayoutDemo frm = new BoxLayoutDemo();
        frm.setVisible(true);
    }
}

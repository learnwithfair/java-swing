package Layout;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class GridayoutDemo extends JFrame {
    private Container c;
    private Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JButton btn1, btn2, btn3, btn4, btn5, btn6;
    private GridLayout glayout;
    GridayoutDemo() {
        this.setTitle("This is Grid Layout");
        this.setBounds(20, 29, 400, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.MAGENTA);
        glayout = new GridLayout(2, 3);
        c.setLayout(glayout);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        btn6 = new JButton("6");
        btn1.setFont(f);
        btn2.setFont(f);
        btn3.setFont(f);
        btn4.setFont(f);
        btn5.setFont(f);
        btn6.setFont(f);
        c.add(btn1);
        c.add(btn2);
        c.add(btn3);
        c.add(btn4);
        c.add(btn5);
        c.add(btn6);
    }
    public static void main(String[] args) {
        GridayoutDemo frm = new GridayoutDemo();
        frm.setVisible(true);
    }
}

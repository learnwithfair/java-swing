package Layout;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;

public class BorderLayoutDemo extends JFrame {
    private Container c;
    private Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JButton btn1, btn2, btn3, btn4, btn5;
    private BorderLayout blayout;
    BorderLayoutDemo() {
        this.setTitle("This is Border Layout");
        this.setBounds(20, 29, 400, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.red);
        blayout = new BorderLayout(5, 10);
        c.setLayout(blayout);
        // blayout.setVgap(5);
        //blayout.setHgap(10);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        btn1.setFont(f);
        btn2.setFont(f);
        btn3.setFont(f);
        btn4.setFont(f);
        btn5.setFont(f);
        c.add(btn1, BorderLayout.NORTH);
        c.add(btn2, BorderLayout.EAST);
        c.add(btn3, BorderLayout.SOUTH);
        c.add(btn4, BorderLayout.WEST);
        c.add(btn5, BorderLayout.CENTER);
    }
    public static void main(String[] args) {
        BorderLayoutDemo frm = new BorderLayoutDemo();
        frm.setVisible(true);
    }
}

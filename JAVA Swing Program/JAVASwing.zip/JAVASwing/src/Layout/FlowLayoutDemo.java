package Layout;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;

public class FlowLayoutDemo extends JFrame {

    private Container c;
    private FlowLayout flayout;
    private Font f = new Font("arial", Font.BOLD + Font.ITALIC, 24);
    private JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;

    FlowLayoutDemo() {
        this.setTitle("This is Flow Layout");
        this.setBounds(20, 30, 650, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.BLUE);
        flayout = new FlowLayout(FlowLayout.LEFT);
        flayout.setVgap(10);
        flayout.setHgap(50);
        c.setLayout(flayout);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        btn6 = new JButton("6");
        btn7 = new JButton("7");
        btn8 = new JButton("8");
        btn9 = new JButton("9");
        btn1.setFont(f);
        btn2.setFont(f);
        btn3.setFont(f);
        btn4.setFont(f);
        btn5.setFont(f);
        btn6.setFont(f);
        btn7.setFont(f);
        btn8.setFont(f);
        btn9.setFont(f);
        c.add(btn1);
        c.add(btn2);
        c.add(btn3);
        c.add(btn4);
        c.add(btn5);
        c.add(btn6);
        c.add(btn7);
        c.add(btn8);
        c.add(btn9);
    }

    public static void main(String[] args) {
        FlowLayoutDemo frm = new FlowLayoutDemo();
        frm.setVisible(true);
    }
}

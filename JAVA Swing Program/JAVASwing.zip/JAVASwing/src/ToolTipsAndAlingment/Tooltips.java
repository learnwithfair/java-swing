package ToolTipsAndAlingment;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Tooltips extends JFrame {
    private JLabel jl, pl;
    private JTextField tf;
    private JPasswordField pf;
    private Container c;
    private Font f;
    Tooltips() {
        this.setTitle("This is Adding Tool Tip Text");
        this.setBounds(20, 30, 500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        containers();
        jlabel();
        plabel();
    }
    public void containers() {
        c = this.getContentPane();
        c.setBackground(Color.MAGENTA);
        c.setLayout(null);
    }
    public void jlabel() {
        jl = new JLabel();
        jl.setFont(f);
        jl.setText("Enter Your Name : ");
        jl.setForeground(Color.blue);
        jl.setBounds(10, 20, 200, 60);
        c.add(jl);
        tf = new JTextField();
        tf.setFont(f);
        tf.setToolTipText("Hint's Md Rahatul Islam");
        tf.setHorizontalAlignment(JTextField.CENTER);
        tf.setBackground(Color.pink);
        tf.setForeground(Color.red);
        tf.setBounds(220, 20, 200, 60);
        c.add(tf);
    }
    public void plabel() {
        pl = new JLabel();
        pl.setText("Enter Password : ");
        pl.setFont(f);
        pl.setForeground(Color.blue);
        pl.setBounds(10, 100, 200, 60);
        c.add(pl);
        pf = new JPasswordField();
        pf.setFont(f);
        pf.setToolTipText("Password Hint's 123456789");
        pf.setHorizontalAlignment(JPasswordField.CENTER);
        pf.setBackground(Color.pink);
        pf.setForeground(Color.red);
        pf.setBounds(220, 100, 200, 60);
        c.add(pf);
    }
    public static void main(String[] args) {
        Tooltips frame = new Tooltips();
        frame.setVisible(true);
    }
}

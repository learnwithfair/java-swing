package Slider;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JSlider;

public class Sliderdemo extends JFrame {
    Container c;
    Sliderdemo() {
        this.setBounds(420, 50, 500, 400);
        this.setTitle("This is Slider");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        JSlider slider = new JSlider(-20, 20, 0);
        slider.setBounds(60, 90, 390, 50);
        slider.setBackground(Color.magenta);
        slider.setMajorTickSpacing(5);
        slider.setMinorTickSpacing(1);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setForeground(Color.red);
        //slider.setInverted(true);
        c.add(slider);
    }
    public static void main(String[] args) {
        Sliderdemo frm = new Sliderdemo();
        frm.setVisible(true);
    }
}

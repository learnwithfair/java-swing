package FontStyle;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class NewDemo extends JFrame {

    private Container c;
    private JLabel jl;
    private Font f;

    NewDemo() {
        this.setTitle("This is Font Style");
        this.setBounds(20, 30, 500, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        containers();
        jlabel();
    }

    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
    }

    public void jlabel() {
        jl = new JLabel();
        jl.setText("Md Rahatul Islam");
        jl.setBounds(50, 90, 200, 60);
        f = new Font("Times new Roman", Font.BOLD + Font.ITALIC, 22);
        jl.setFont(f);
        jl.setOpaque(true);
        jl.setBackground(Color.magenta);
        jl.setForeground(Color.BLUE);
        c.add(jl);
    }

    public static void main(String[] args) {
        NewDemo frame = new NewDemo();
        frame.setVisible(true);
    }
}

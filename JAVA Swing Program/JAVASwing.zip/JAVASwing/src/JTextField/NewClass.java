package JTextField;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class NewClass extends JFrame {

    private Container c;
    private JTextField tf;
    private JLabel jl;
    private Font f;

    NewClass() {
        this.setTitle("This is JTextField");
        this.setBounds(20, 30, 500, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        containers();
        jlabel();
    }

    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.MAGENTA);
    }

    public void jlabel() {
        jl = new JLabel();
        jl.setText("Enter Your Name : ");
        jl.setForeground(Color.BLUE);
        jl.setFont(f);
        jl.setBounds(10, 20, 200, 60);
        c.add(jl);

        tf = new JTextField();
        tf.setBackground(Color.pink);
        tf.setForeground(Color.red);
        tf.setFont(f);
        tf.setBounds(220, 20, 200, 60);
        c.add(tf);
    }

    public static void main(String[] args) {
        NewClass frame = new NewClass();
        frame.setVisible(true);
    }
}

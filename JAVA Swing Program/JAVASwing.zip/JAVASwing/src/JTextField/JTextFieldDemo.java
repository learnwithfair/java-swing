package JTextField;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class JTextFieldDemo extends JFrame {

    private Container c;
    private JTextField tf;
    private JPasswordField pf;
    private JLabel jl, pl;
    private Font f;

    JTextFieldDemo() {
        this.setTitle("This is JTextField");
        this.setBounds(20, 30, 500, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f = new Font("arial", Font.BOLD + Font.ITALIC, 22);
        containers();
        jlabel();
        plabel();
    }

    public void containers() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.MAGENTA);
    }

    public void jlabel() {
        jl = new JLabel();
        jl.setText("Enter Your Name : ");
        jl.setForeground(Color.BLUE);
        jl.setFont(f);
        jl.setBounds(10, 20, 200, 60);
        c.add(jl);

        tf = new JTextField();
        tf.setBackground(Color.pink);
        tf.setForeground(Color.red);
        tf.setFont(f);
        tf.setBounds(220, 20, 200, 60);
        c.add(tf);
    }

    public void plabel() {
        pl = new JLabel();
        pl.setText("Enter Password : ");
        pl.setForeground(Color.blue);
        pl.setFont(f);
        pl.setBounds(10, 100, 200, 60);
        c.add(pl);

        pf = new JPasswordField();
        pf.setBackground(Color.pink);
        pf.setFont(f);
        pf.setBounds(220, 100, 200, 60);
        c.add(pf);
    }

    public static void main(String[] args) {
        JTextFieldDemo frame = new JTextFieldDemo();
        frame.setVisible(true);
    }
}

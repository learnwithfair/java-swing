package JTabbedPane;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class JTabbedPaneDemo extends JFrame {

    private Container c;
    private JLabel lb1, lb2, lb3;
    private Font f = new Font("Times New Roman", Font.BOLD, 24);
    private JPanel pnl1, pnl2, pnl3;
    private GridBagLayout gb;

    JTabbedPaneDemo() {
        this.setBounds(20, 29, 600, 600);
        this.setTitle("This is JTabbedPaneDemo");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        gb = new GridBagLayout();
        lb1 = new JLabel("This is Panel one");
        lb1.setFont(f);
        lb1.setForeground(Color.BLACK);
        lb2 = new JLabel("This is Panel Two");
        lb2.setFont(f);
        lb2.setForeground(Color.BLACK);
        lb3 = new JLabel("This is Panel Three");
        lb3.setFont(f);
        lb3.setForeground(Color.BLACK);
        pnl1 = new JPanel();
        pnl1.setLayout(gb);
        pnl1.setBackground(Color.red);
        pnl2 = new JPanel();
        pnl2.setLayout(gb);
        pnl2.setBackground(Color.green);
        pnl3 = new JPanel();
        pnl3.setLayout(gb);
        pnl3.setBackground(Color.BLUE);
        pnl1.add(lb1);
        pnl2.add(lb2);
        pnl3.add(lb3);
        JTabbedPane tab = new JTabbedPane();
        //JTabbedPane tab = new JTabbedPane(JTabbedPane.BOTTOM);
        //tab.setTabPlacement(JTabbedPane.BOTTOM);
        tab.setBounds(40, 20, 500, 450);
        //tab.addTab(string, icon, c);
        // tab.addTab(string, icon, c, string1);
        tab.addTab("Home", pnl1);
        tab.addTab("Help", pnl2);
        tab.addTab("Edit", pnl3);
        c.add(tab);
    }

    public static void main(String[] args) {
        JTabbedPaneDemo frm = new JTabbedPaneDemo();
        frm.setVisible(true);
    }
}

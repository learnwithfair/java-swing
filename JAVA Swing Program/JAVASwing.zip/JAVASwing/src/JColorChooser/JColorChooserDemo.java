package JColorChooser;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;

public class JColorChooserDemo extends JFrame implements ActionListener {

    Container c;
    Font f = new Font("Times New Roman", Font.BOLD, 24);
    JButton btn;

    JColorChooserDemo() {
        this.setBounds(20, 29, 400, 500);
        this.setTitle("This is JColorChooser");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        btn = new JButton("Choice a Color");
        btn.setBounds(90, 120, 200, 60);
        btn.setFont(f);
        c.add(btn);
        btn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        Color color = JColorChooser.showDialog(c, " Select a Color", Color.yellow);
        c.setBackground(color);
    }

    public static void main(String[] args) {
        JColorChooserDemo frm = new JColorChooserDemo();
        frm.setVisible(true);
    }

}

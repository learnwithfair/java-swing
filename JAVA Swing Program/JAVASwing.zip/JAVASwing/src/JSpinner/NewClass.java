package JSpinner;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class NewClass extends JFrame {

    private Container c;
    private Font f;
    private JSpinner spinner;

    NewClass() {
        this.setBounds(20, 29, 400, 500);
        this.setTitle("This is Spinner");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setBackground(Color.BLUE);
        c.setLayout(null);
        SpinnerNumberModel s = new SpinnerNumberModel(10, 0, 30, 2);
        spinner = new JSpinner(s);
        spinner.setBounds(20, 29, 90, 60);
        //spinner.setValue(10);
        c.add(spinner);
    }

    public static void main(String[] args) {
        NewClass frm = new NewClass();
        frm.setVisible(true);
    }
}

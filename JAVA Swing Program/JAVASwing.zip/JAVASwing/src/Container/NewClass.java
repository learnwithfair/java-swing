package Container;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;

public class NewClass extends JFrame {

    private Container c;

    NewClass() {
        this.setTitle("This is JFrame");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(20, 30, 600, 500);
        initcomponents();
       
    }

    public void initcomponents() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.BLUE);
    }

    public static void main(String[] args) {
        NewClass frame = new NewClass();
        frame.setVisible(true);
    }
}

package JTabble;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class JTabbleDemo extends JFrame {

    private Container c;
    private Font f = new Font("Times New Roman", Font.BOLD, 24);
    private JTable tbl;
    private JScrollPane scroll;
    private String[] cols = {"Name", "ID", "GPA"};
    private String[][] rows = {
        {"  Rahatul", "        201", "        3.98"},
        {"  Sumon", "        202", "        2.98"},
        {"  Sonjoy", "        203", "        1.98"},
        {"  Sujon", "        204", "        2.08"},
        {"  Pinky", "        205", "        3.44"}};

    JTabbleDemo() {
        this.setBounds(20, 29, 600, 600);
        this.setTitle("This is ");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.magenta);
        tbl = new JTable(rows, cols);
        //tbl.setEnabled(false);
        tbl.setRowSelectionAllowed(true);
        tbl.setRowHeight(50);
        tbl.setFont(f);
        tbl.setSelectionBackground(Color.yellow);
        //tbl.setCellSelectionEnabled(false);
        scroll = new JScrollPane(tbl);
        scroll.setBounds(80, 90, 400, 300);
        c.add(scroll);
    }

    public static void main(String[] args) {
        JTabbleDemo frm = new JTabbleDemo();
        frm.setVisible(true);
    }
}
